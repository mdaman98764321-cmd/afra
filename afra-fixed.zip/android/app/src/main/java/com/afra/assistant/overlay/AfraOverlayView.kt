package com.afra.assistant.overlay

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.*
import android.view.View
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.animation.LinearInterpolator
import androidx.core.content.ContextCompat

/**
 * Custom Android View for the 56dp Floating Avatar Overlay with hardware-accelerated
 * Canvas drawing, state glow animations, and explicit microphone status indicator.
 */
class AfraOverlayView(context: Context) : View(context) {

    private var currentState = "idle"
    private var audioAmplitude = 0f
    private var isPressedScale = false
    private var showMicIndicator = false

    // Color definitions
    private val colorViolet = Color.parseColor("#8B5CF6")
    private val colorCyan = Color.parseColor("#06B6D4")
    private val colorEmerald = Color.parseColor("#10B981")
    private val colorRose = Color.parseColor("#F43F5E")
    private val colorBgDark = Color.parseColor("#0B0D10")
    private val colorBorder = Color.parseColor("#334155")

    // Paints
    private val haloPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }

    private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 2.5f * resources.displayMetrics.density
        color = colorBorder
    }

    private val orbitPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 2f * resources.displayMetrics.density
        color = colorViolet
    }

    private val corePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = colorBgDark
    }

    private val micBadgePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = colorCyan
    }

    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        textSize = 14f * resources.displayMetrics.density
    }

    // Animators
    private var orbitAngle = 0f
    private var breathFraction = 0f
    private val orbitAnimator: ValueAnimator = ValueAnimator.ofFloat(0f, 360f).apply {
        duration = 1600
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener {
            orbitAngle = it.animatedValue as Float
            invalidate()
        }
    }

    private val breathAnimator: ValueAnimator = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 2400
        repeatCount = ValueAnimator.INFINITE
        repeatMode = ValueAnimator.REVERSE
        interpolator = AccelerateDecelerateInterpolator()
        addUpdateListener {
            breathFraction = it.animatedValue as Float
            invalidate()
        }
    }

    init {
        breathAnimator.start()
    }

    fun setAnimationState(state: String, level: Float = 0f) {
        currentState = state.lowercase()
        audioAmplitude = level

        if (currentState == "thinking" && !orbitAnimator.isRunning) {
            orbitAnimator.start()
        } else if (currentState != "thinking" && orbitAnimator.isRunning) {
            orbitAnimator.cancel()
        }

        invalidate()
    }

    fun setPressedScale(pressed: Boolean) {
        isPressedScale = pressed
        invalidate()
    }

    fun showMicrophoneIndicator(show: Boolean) {
        showMicIndicator = show
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        val cx = width / 2f
        val cy = height / 2f
        val baseRadius = (width.coerceAtMost(height) / 2f) - (8f * resources.displayMetrics.density)

        // Scale factor for press/speech feedback
        val scale = when {
            isPressedScale -> 0.92f
            currentState == "speaking" -> 1f + (audioAmplitude * 0.12f)
            currentState == "happy" -> 1.06f
            else -> 1f + (breathFraction * 0.03f)
        }

        canvas.save()
        canvas.scale(scale, scale, cx, cy)

        // 1. Draw dynamic state glow halo
        val glowColor = when (currentState) {
            "listening" -> colorCyan
            "thinking" -> colorViolet
            "speaking" -> colorCyan
            "happy" -> colorEmerald
            "error" -> colorRose
            else -> colorViolet
        }

        val glowRadius = baseRadius + (6f * resources.displayMetrics.density) + (audioAmplitude * 10f)
        haloPaint.shader = RadialGradient(
            cx, cy, glowRadius,
            glowColor,
            Color.TRANSPARENT,
            Shader.TileMode.CLAMP
        )
        haloPaint.alpha = when (currentState) {
            "listening" -> 160
            "speaking" -> 180
            "thinking" -> 140
            "happy" -> 150
            "error" -> 170
            else -> 90
        }
        canvas.drawCircle(cx, cy, glowRadius, haloPaint)

        // 2. Draw core avatar circle
        canvas.drawCircle(cx, cy, baseRadius, corePaint)

        // 3. Draw state specific animations
        when (currentState) {
            "thinking" -> {
                // Orbiting ring
                val orbitRadius = baseRadius + (3f * resources.displayMetrics.density)
                val rect = RectF(
                    cx - orbitRadius, cy - orbitRadius,
                    cx + orbitRadius, cy + orbitRadius
                )
                canvas.drawArc(rect, orbitAngle, 100f, false, orbitPaint)
            }
            "listening" -> {
                // Sound wave ring
                val pulseRadius = baseRadius + (audioAmplitude * 8f * resources.displayMetrics.density)
                borderPaint.color = colorCyan
                canvas.drawCircle(cx, cy, pulseRadius, borderPaint)
            }
        }

        // 4. Central Monogram / Avatar Graphic
        borderPaint.color = when (currentState) {
            "listening" -> colorCyan
            "speaking" -> colorViolet
            "happy" -> colorEmerald
            "error" -> colorRose
            else -> colorBorder
        }
        canvas.drawCircle(cx, cy, baseRadius, borderPaint)

        // Letter "A" monogram with subtle glow
        textPaint.color = when (currentState) {
            "listening" -> colorCyan
            "error" -> colorRose
            else -> Color.WHITE
        }
        val textY = cy - ((textPaint.descent() + textPaint.ascent()) / 2f)
        canvas.drawText("A", cx, textY, textPaint)

        // 5. Microphone Privacy Badge (Top Right)
        if (showMicIndicator || currentState == "listening") {
            val badgeRadius = 5f * resources.displayMetrics.density
            val badgeX = cx + (baseRadius * 0.7f)
            val badgeY = cy - (baseRadius * 0.7f)
            canvas.drawCircle(badgeX, badgeY, badgeRadius, micBadgePaint)
        }

        canvas.restore()
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        orbitAnimator.cancel()
        breathAnimator.cancel()
    }
}
