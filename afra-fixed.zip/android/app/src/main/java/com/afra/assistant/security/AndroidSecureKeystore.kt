package com.afra.assistant.security

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/**
 * Android Keystore-backed secure storage for user Gemini API keys.
 * Encrypts API keys at rest using Android KeyStore and AES-256 GCM encryption.
 */
class AndroidSecureKeystore(context: Context) {

    private val sharedPreferences: SharedPreferences

    init {
        val masterKey = MasterKey.Builder(context)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()

        sharedPreferences = EncryptedSharedPreferences.create(
            context,
            "afra_secure_keystore_prefs",
            masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    }

    fun saveApiKey(apiKey: String) {
        sharedPreferences.edit().putString("secure_gemini_api_key", apiKey.trim()).apply()
    }

    fun getApiKey(): String {
        return sharedPreferences.getString("secure_gemini_api_key", "") ?: ""
    }

    fun clearApiKey() {
        sharedPreferences.edit().remove("secure_gemini_api_key").apply()
    }
}
