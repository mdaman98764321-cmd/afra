package com.afra.assistant.overlay

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.max

/**
 * Native Quick Action Menu floating panel displayed when tapping the floating avatar.
 * Contains:
 * 1. Open Afra Chat
 * 2. Start Voice Conversation
 * 3. Quick Message (inline floating prompt dialog)
 * 4. Return to Full App
 * 5. Hide Avatar
 * 6. Close Floating Assistant
 */
class QuickActionMenu(
    private val context: Context,
    private val windowManager: WindowManager,
    private val onOpenChat: () -> Unit,
    private val onStartVoice: () -> Unit,
    private val onQuickMessage: () -> Unit,
    private val onReturnToApp: () -> Unit,
    private val onHide: () -> Unit,
    private val onClose: () -> Unit
) {

    private var menuView: View? = null
    private var quickInputView: View? = null
    private var isShowing = false

    fun isShowing(): Boolean = isShowing

    fun show(avatarX: Int, avatarY: Int, showOnLeft: Boolean) {
        if (isShowing) return

        val density = context.resources.displayMetrics.density
        val menuWidthPx = (220 * density).toInt()

        val root = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            val pad = (12 * density).toInt()
            setPadding(pad, pad, pad, pad)
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#0E1217"))
                setStroke((1 * density).toInt(), Color.parseColor("#1E293B"))
                cornerRadius = 16 * density
            }
            elevation = 12 * density
        }

        // Header Title
        val titleView = TextView(context).apply {
            text = "AFRA Quick Actions"
            setTextColor(Color.WHITE)
            textSize = 13f
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            setPadding(0, 0, 0, (8 * density).toInt())
        }
        root.addView(titleView)

        // Menu Actions
        val actions = listOf(
            MenuAction("💬  Open Afra Chat", Color.parseColor("#8B5CF6"), onOpenChat),
            MenuAction("🎙️  Start Voice Mode", Color.parseColor("#06B6D4"), onStartVoice),
            MenuAction("⚡  Quick Message", Color.WHITE, onQuickMessage),
            MenuAction("📱  Return to Full App", Color.parseColor("#94A3B8"), onReturnToApp),
            MenuAction("👁️  Hide Avatar", Color.parseColor("#64748B"), onHide),
            MenuAction("✕  Close Assistant", Color.parseColor("#F43F5E"), onClose)
        )

        for (action in actions) {
            val btn = Button(context).apply {
                text = action.title
                setTextColor(action.textColor)
                textSize = 12f
                isAllCaps = false
                gravity = Gravity.START or Gravity.CENTER_VERTICAL
                background = GradientDrawable().apply {
                    setColor(Color.parseColor("#161D26"))
                    cornerRadius = 10 * density
                }
                val btnPadH = (12 * density).toInt()
                val btnPadV = (8 * density).toInt()
                setPadding(btnPadH, btnPadV, btnPadH, btnPadV)
                val params = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply {
                    topMargin = (4 * density).toInt()
                }
                layoutParams = params
                setOnClickListener {
                    action.onClick()
                }
            }
            root.addView(btn)
        }

        val overlayType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val layoutParams = WindowManager.LayoutParams(
            menuWidthPx,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                    WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = if (showOnLeft) max(16, avatarX - menuWidthPx - (12 * density).toInt()) else avatarX + (64 * density).toInt()
            y = max(48, avatarY)
        }

        root.setOnTouchListener { _, event ->
            if (event.action == android.view.MotionEvent.ACTION_OUTSIDE) {
                dismiss()
                true
            } else {
                false
            }
        }

        try {
            windowManager.addView(root, layoutParams)
            menuView = root
            isShowing = true
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun showQuickInputModal(onSend: (String) -> Unit) {
        dismiss()
        val density = context.resources.displayMetrics.density

        val container = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            val pad = (16 * density).toInt()
            setPadding(pad, pad, pad, pad)
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#0B0D10"))
                setStroke((1 * density).toInt(), Color.parseColor("#8B5CF6"))
                cornerRadius = 18 * density
            }
        }

        val title = TextView(context).apply {
            text = "Ask AFRA Quick Query"
            setTextColor(Color.WHITE)
            textSize = 14f
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            setPadding(0, 0, 0, (8 * density).toInt())
        }
        container.addView(title)

        val input = EditText(context).apply {
            hint = "Type your request..."
            setHintTextColor(Color.parseColor("#64748B"))
            setTextColor(Color.WHITE)
            textSize = 13f
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#161D26"))
                cornerRadius = 8 * density
            }
            val editPad = (10 * density).toInt()
            setPadding(editPad, editPad, editPad, editPad)
        }
        container.addView(input)

        val row = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.END
            topMargin = (10 * density).toInt()
        }

        val cancelBtn = Button(context).apply {
            text = "Cancel"
            setTextColor(Color.parseColor("#94A3B8"))
            textSize = 12f
            background = null
            setOnClickListener { dismissQuickInput() }
        }
        row.addView(cancelBtn)

        val sendBtn = Button(context).apply {
            text = "Send"
            setTextColor(Color.WHITE)
            textSize = 12f
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#8B5CF6"))
                cornerRadius = 8 * density
            }
            setOnClickListener {
                val q = input.text.toString().trim()
                if (q.isNotEmpty()) {
                    onSend(q)
                    dismissQuickInput()
                }
            }
        }
        row.addView(sendBtn)
        container.addView(row)

        val overlayType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val modalWidth = (context.resources.displayMetrics.widthPixels * 0.85f).toInt()
        val params = WindowManager.LayoutParams(
            modalWidth,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_DIM_BEHIND,
            PixelFormat.TRANSLUCENT
        ).apply {
            dimAmount = 0.5f
            gravity = Gravity.CENTER
        }

        try {
            windowManager.addView(container, params)
            quickInputView = container
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun dismissQuickInput() {
        quickInputView?.let {
            try {
                windowManager.removeView(it)
            } catch (e: Exception) {}
        }
        quickInputView = null
    }

    fun dismiss() {
        if (!isShowing) return
        menuView?.let {
            try {
                windowManager.removeView(it)
            } catch (e: Exception) {}
        }
        menuView = null
        isShowing = false
    }

    private data class MenuAction(
        val title: String,
        val textColor: Int,
        val onClick: () -> Unit
    )
}
