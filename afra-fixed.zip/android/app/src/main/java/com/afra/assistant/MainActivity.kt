package com.afra.assistant

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.view.KeyEvent
import android.view.ViewGroup
import android.webkit.JavascriptInterface
import android.webkit.PermissionRequest
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.webkit.WebViewAssetLoader
import com.afra.assistant.bridge.AfraNativeBridge
import org.json.JSONObject

/**
 * Hosts the AFRA web app inside a WebView.
 * - Loads the packaged app from a secure virtual https address (so storage and audio work properly).
 * - Provides native speech recognition (Android WebView has no built-in Web Speech API).
 */
class MainActivity : ComponentActivity() {

    private lateinit var webView: WebView
    private lateinit var assetLoader: WebViewAssetLoader

    private var recognizer: SpeechRecognizer? = null
    private var wantListening = false
    private var listenLang = "bn-BD"
    private val handler = Handler(Looper.getMainLooper())

    companion object {
        private const val HOME_URL = "https://appassets.androidplatform.net/assets/index.html"
        private const val REQ_MIC = 7001

        // Makes the web app's speech code use the phone's native recognizer.
        private const val SPEECH_POLYFILL = """
(function(){
  if (window.__afraSRInstalled) return;
  window.__afraSRInstalled = true;
  var active = null;
  function SR(){ this.continuous=false; this.interimResults=false; this.lang='bn-BD';
    this.onresult=null; this.onerror=null; this.onend=null; this.onstart=null; }
  SR.prototype.start=function(){ active=this; window.AfraSpeech.start(this.lang||'bn-BD'); if(this.onstart) this.onstart({}); };
  SR.prototype.stop=function(){ window.AfraSpeech.stop(); };
  SR.prototype.abort=function(){ window.AfraSpeech.stop(); };
  window.__afraSR = {
    result:function(t,f){ if(!active||!active.onresult) return;
      var res=[{transcript:t,confidence:0.9}]; res.isFinal=f;
      active.onresult({resultIndex:0,results:[res]}); },
    error:function(c){ if(active&&active.onerror) active.onerror({error:c}); },
    end:function(){ if(active&&active.onend) active.onend({}); }
  };
  window.SpeechRecognition=SR; window.webkitSpeechRecognition=SR;
})();
"""
    }

    inner class SpeechJsBridge {
        @JavascriptInterface
        fun start(lang: String) {
            runOnUiThread { beginListening(lang) }
        }

        @JavascriptInterface
        fun stop() {
            runOnUiThread { endListening(true) }
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        assetLoader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        webView = WebView(this).apply {
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            setBackgroundColor(Color.parseColor("#0B0D10"))

            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                loadsImagesAutomatically = true
                mediaPlaybackRequiresUserGesture = false
                cacheMode = WebSettings.LOAD_DEFAULT
                setSupportZoom(false)
                builtInZoomControls = false
                allowFileAccess = false
                allowContentAccess = false
            }

            webViewClient = object : WebViewClient() {
                override fun shouldInterceptRequest(
                    view: WebView?,
                    request: WebResourceRequest
                ): WebResourceResponse? = assetLoader.shouldInterceptRequest(request.url)

                override fun onPageFinished(view: WebView?, url: String?) {
                    view?.evaluateJavascript(SPEECH_POLYFILL, null)
                }
            }

            // The microphone is used by the native speech recognizer, so the page itself
            // is not given direct microphone access (two apps parts can't share it at once).
            webChromeClient = object : WebChromeClient() {
                override fun onPermissionRequest(request: PermissionRequest?) {
                    request?.deny()
                }
            }
        }

        webView.addJavascriptInterface(AfraNativeBridge(this, webView), "AndroidAfraBridge")
        webView.addJavascriptInterface(SpeechJsBridge(), "AfraSpeech")

        // Keep content clear of status bar, navigation bar and keyboard.
        ViewCompat.setOnApplyWindowInsetsListener(webView) { v, insets ->
            val bars = insets.getInsets(
                WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.ime()
            )
            v.setPadding(bars.left, bars.top, bars.right, bars.bottom)
            WindowInsetsCompat.CONSUMED
        }

        setContentView(webView)

        if (savedInstanceState == null) {
            webView.loadUrl(HOME_URL)
        } else {
            webView.restoreState(savedInstanceState)
        }
    }

    /* ---------------- native speech recognition ---------------- */

    private fun emit(js: String) {
        webView.post { webView.evaluateJavascript(js, null) }
    }

    private fun beginListening(lang: String) {
        listenLang = lang
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), REQ_MIC)
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            emit("window.__afraSR && window.__afraSR.error('service-not-allowed');")
            return
        }
        wantListening = true
        startRecognizer()
    }

    private fun startRecognizer() {
        try {
            recognizer?.destroy()
            val r = SpeechRecognizer.createSpeechRecognizer(this)
            r.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onEvent(eventType: Int, params: Bundle?) {}

                override fun onPartialResults(partialResults: Bundle?) {
                    val t = partialResults
                        ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        ?.firstOrNull()
                    if (!t.isNullOrBlank()) {
                        emit("window.__afraSR && window.__afraSR.result(${JSONObject.quote(t)}, false);")
                    }
                }

                override fun onResults(results: Bundle?) {
                    val t = results
                        ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        ?.firstOrNull()
                    if (!t.isNullOrBlank()) {
                        emit("window.__afraSR && window.__afraSR.result(${JSONObject.quote(t)}, true);")
                    }
                    restartIfWanted(200)
                }

                override fun onError(error: Int) {
                    when (error) {
                        SpeechRecognizer.ERROR_NO_MATCH,
                        SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> restartIfWanted(300)
                        SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> restartIfWanted(800)
                        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> fail("not-allowed")
                        SpeechRecognizer.ERROR_NETWORK,
                        SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> fail("network")
                        else -> fail("audio-capture")
                    }
                }
            })
            recognizer = r
            r.startListening(
                Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, listenLang)
                    putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                    putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
                }
            )
        } catch (e: Exception) {
            fail("audio-capture")
        }
    }

    private fun restartIfWanted(delayMs: Long) {
        if (!wantListening) return
        handler.postDelayed({ if (wantListening) startRecognizer() }, delayMs)
    }

    private fun fail(code: String) {
        endListening(false)
        emit("window.__afraSR && window.__afraSR.error(${JSONObject.quote(code)});")
        emit("window.__afraSR && window.__afraSR.end();")
    }

    private fun endListening(notify: Boolean) {
        wantListening = false
        handler.removeCallbacksAndMessages(null)
        try {
            recognizer?.cancel()
            recognizer?.destroy()
        } catch (e: Exception) {
            e.printStackTrace()
        }
        recognizer = null
        if (notify) emit("window.__afraSR && window.__afraSR.end();")
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_MIC) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                beginListening(listenLang)
            } else {
                emit("window.__afraSR && window.__afraSR.error('not-allowed');")
                emit("window.__afraSR && window.__afraSR.end();")
            }
        }
    }

    /* ---------------- lifecycle ---------------- */

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        webView.saveState(outState)
    }

    override fun onResume() {
        super.onResume()
        webView.onResume()
        webView.resumeTimers()
    }

    override fun onPause() {
        endListening(false)
        webView.onPause()
        webView.pauseTimers()
        super.onPause()
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_BACK && webView.canGoBack()) {
            webView.goBack()
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onDestroy() {
        endListening(false)
        try {
            (webView.parent as? ViewGroup)?.removeView(webView)
            webView.stopLoading()
            webView.destroy()
        } catch (e: Exception) {
            e.printStackTrace()
        }
        super.onDestroy()
    }
}
