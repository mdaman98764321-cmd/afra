import { VoiceProfileId } from '../types';
import { VOICE_PROFILES } from './voiceProfiles';
import { ApiKeyStorage } from './apiKeyStorage';

export interface SpeechVoiceOption {
  name: string;
  lang: string;
  isDefault: boolean;
  isFemale: boolean;
}

// Known female voice name substrings for strict Web Speech API filtering
const FEMALE_VOICE_KEYWORDS = [
  'female',
  'woman',
  'girl',
  'samantha',
  'victoria',
  'karen',
  'moira',
  'tessa',
  'fiona',
  'veena',
  'zira',
  'hazel',
  'susan',
  'catherine',
  'heera',
  'ananya',
  'bangla',
  'bangladesh',
  'bengali',
  'shrabani',
  'mitu',
  'monica',
  'paulina',
  'helena',
  'ioana',
  'milena',
  'luciana',
  'kyoko',
  'yuna',
  'sin-ji',
  'ting-ting',
  'mei-jia',
  'google uk english female',
  'google us english',
  'microsoft zira',
  'natural female',
];

class AudioController {
  private audioCtx: AudioContext | null = null;
  private analyser: AnalyserNode | null = null;
  private mediaStream: MediaStream | null = null;
  private sourceNode: MediaStreamAudioSourceNode | null = null;
  private currentAudioElement: HTMLAudioElement | null = null;
  private audioSourceNode: MediaElementAudioSourceNode | null = null;
  private levelAnimationId: number | null = null;
  private synthInterval: number | null = null;
  private recognition: any = null;

  public initAudioContext(): AudioContext {
    if (!this.audioCtx) {
      const AudioCtxClass = window.AudioContext || (window as any).webkitAudioContext;
      this.audioCtx = new AudioCtxClass();
    }
    if (this.audioCtx.state === 'suspended') {
      this.audioCtx.resume();
    }
    return this.audioCtx;
  }

  // Play subtle futuristic UI sound effects using Web Audio API
  public playSound(type: 'activate' | 'state' | 'chirp' | 'complete'): void {
    try {
      const ctx = this.initAudioContext();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.connect(gain);
      gain.connect(ctx.destination);

      const now = ctx.currentTime;

      if (type === 'activate') {
        osc.type = 'sine';
        osc.frequency.setValueAtTime(440, now);
        osc.frequency.exponentialRampToValueAtTime(880, now + 0.12);
        gain.gain.setValueAtTime(0.08, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.18);
        osc.start(now);
        osc.stop(now + 0.18);
      } else if (type === 'state') {
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(600, now);
        osc.frequency.exponentialRampToValueAtTime(750, now + 0.08);
        gain.gain.setValueAtTime(0.05, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.1);
        osc.start(now);
        osc.stop(now + 0.1);
      } else if (type === 'chirp') {
        osc.type = 'sine';
        osc.frequency.setValueAtTime(880, now);
        osc.frequency.exponentialRampToValueAtTime(1320, now + 0.09);
        gain.gain.setValueAtTime(0.06, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.15);
        osc.start(now);
        osc.stop(now + 0.15);
      } else if (type === 'complete') {
        osc.type = 'sine';
        osc.frequency.setValueAtTime(520, now);
        osc.frequency.setValueAtTime(660, now + 0.08);
        gain.gain.setValueAtTime(0.05, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.22);
        osc.start(now);
        osc.stop(now + 0.22);
      }
    } catch (e) {
      // Audio might be blocked by autoplay policy until user gesture
    }
  }

  // Get strictly filtered female voices from Web Speech API
  public getVoices(): SpeechVoiceOption[] {
    if (!('speechSynthesis' in window)) return [];
    const voices = window.speechSynthesis.getVoices();
    return voices.map((v) => {
      const lower = (v.name + ' ' + v.lang).toLowerCase();
      const isFemale = FEMALE_VOICE_KEYWORDS.some((kw) => lower.includes(kw));
      return {
        name: v.name,
        lang: v.lang,
        isDefault: v.default,
        isFemale,
      };
    });
  }

  // Find a verified female voice from Web Speech API
  private findVerifiedFemaleVoice(preferredVoiceName?: string): SpeechSynthesisVoice | null {
    if (!('speechSynthesis' in window)) return null;
    const voices = window.speechSynthesis.getVoices();

    if (preferredVoiceName) {
      const exactMatch = voices.find((v) => v.name === preferredVoiceName);
      if (exactMatch) {
        const lower = (exactMatch.name + ' ' + exactMatch.lang).toLowerCase();
        // If explicitly named female or safe
        if (FEMALE_VOICE_KEYWORDS.some((kw) => lower.includes(kw))) {
          return exactMatch;
        }
      }
    }

    // Search for any verified female voice
    for (const kw of FEMALE_VOICE_KEYWORDS) {
      const match = voices.find((v) => (v.name + ' ' + v.lang).toLowerCase().includes(kw));
      if (match) return match;
    }

    return null;
  }

  // Stop any active speech (Gemini audio or SpeechSynthesis)
  public stopSpeaking(): void {
    if (this.currentAudioElement) {
      try {
        this.currentAudioElement.pause();
        this.currentAudioElement.currentTime = 0;
      } catch (e) {}
      this.currentAudioElement = null;
    }

    if (this.levelAnimationId) {
      cancelAnimationFrame(this.levelAnimationId);
      this.levelAnimationId = null;
    }

    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
  }

  // High-fidelity speech pipeline with Gemini TTS (Female Zephyr & Kore) and strict female fallback
  public async speak(
    text: string,
    options: {
      voiceProfile?: VoiceProfileId;
      rate?: number;
      pitch?: number;
      onStart?: () => void;
      onAudioLevel?: (level: number) => void;
      onEnd?: () => void;
      onError?: (errMsg: string) => void;
    }
  ): Promise<void> {
    this.stopSpeaking();

    const cleanText = text
      .replace(/[*#`_~]/g, '')
      .replace(/\[([^\]]+)\]\([^)]+\)/g, '$1')
      .replace(/```[\s\S]*?```/g, '')
      .trim();

    if (!cleanText) {
      options.onEnd?.();
      return;
    }

    const voiceProfile = options.voiceProfile || 'afra-soft';
    const apiKey = ApiKeyStorage.getApiKey();

    // 1. Try server-side Gemini TTS first (Zephyr / Kore female voices)
    if (apiKey) {
      try {
        const res = await fetch('/api/tts', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'x-gemini-api-key': apiKey,
          },
          body: JSON.stringify({
            text: cleanText,
            voiceProfile,
          }),
        });

        if (res.ok) {
          const data = await res.json();
          if (data.audioData) {
            await this.playGeminiAudio(data.audioData, options);
            return;
          }
        }
      } catch (apiErr) {
        console.warn('[AFRA Voice] Server TTS call failed, evaluating verified female fallback:', apiErr);
      }
    }

    // 2. Strict Fallback: Use verified female voice from Web Speech API
    // Requirement 6: "If a voice is unavailable, show an error rather than silently switching to a male voice."
    const femaleVoice = this.findVerifiedFemaleVoice();
    if (!femaleVoice) {
      const errorMsg =
        'Female voice profile is unavailable. Default male TTS was prevented to preserve AFRA voice profile integrity.';
      console.error('[AFRA Voice]', errorMsg);
      options.onError?.(errorMsg);
      return;
    }

    this.playWebSpeechFallback(cleanText, femaleVoice, voiceProfile, options);
  }

  // Play Gemini WAV audio with real-time AnalyserNode level modulation for avatars
  private async playGeminiAudio(
    base64Data: string,
    options: {
      onStart?: () => void;
      onAudioLevel?: (level: number) => void;
      onEnd?: () => void;
      onError?: (errMsg: string) => void;
    }
  ): Promise<void> {
    const audio = new Audio(`data:audio/wav;base64,${base64Data}`);
    this.currentAudioElement = audio;

    // Connect to Web Audio Analyser so the avatar pulses with the actual female voice waveform
    try {
      const ctx = this.initAudioContext();
      const source = ctx.createMediaElementSource(audio);
      const analyser = ctx.createAnalyser();
      analyser.fftSize = 256;
      source.connect(analyser);
      analyser.connect(ctx.destination);

      const dataArray = new Uint8Array(analyser.frequencyBinCount);
      const updateLevel = () => {
        if (!this.currentAudioElement || this.currentAudioElement.paused) return;
        analyser.getByteFrequencyData(dataArray);
        let sum = 0;
        for (let i = 0; i < dataArray.length; i++) {
          sum += dataArray[i];
        }
        const avg = sum / dataArray.length;
        const normalized = Math.min(1, avg / 70);
        options.onAudioLevel?.(normalized);
        this.levelAnimationId = requestAnimationFrame(updateLevel);
      };

      audio.onplay = () => {
        options.onStart?.();
        updateLevel();
      };
    } catch (e) {
      // If CORS or media element source already connected, simulate envelope
      let phase = 0;
      const interval = setInterval(() => {
        if (!this.currentAudioElement || this.currentAudioElement.paused) {
          clearInterval(interval);
          return;
        }
        phase += 0.3;
        const level = (Math.abs(Math.sin(phase)) * 0.6 + 0.2) * 0.9;
        options.onAudioLevel?.(level);
      }, 50);

      audio.onplay = () => {
        options.onStart?.();
      };
    }

    audio.onended = () => {
      this.currentAudioElement = null;
      if (this.levelAnimationId) {
        cancelAnimationFrame(this.levelAnimationId);
        this.levelAnimationId = null;
      }
      options.onAudioLevel?.(0);
      options.onEnd?.();
    };

    audio.onerror = () => {
      this.currentAudioElement = null;
      options.onAudioLevel?.(0);
      options.onError?.('Audio playback failed for the selected female voice.');
    };

    await audio.play().catch((err) => {
      options.onError?.(err?.message || 'Playback blocked by browser autoplay policy.');
    });
  }

  // Play Web Speech API with strict female voice and simulated speech envelope
  private playWebSpeechFallback(
    text: string,
    voice: SpeechSynthesisVoice,
    profile: VoiceProfileId,
    options: {
      onStart?: () => void;
      onAudioLevel?: (level: number) => void;
      onEnd?: () => void;
      onError?: (errMsg: string) => void;
    }
  ): void {
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.voice = voice;

    // Profile acoustic tuning:
    // AFRA Soft: slightly higher pitch, gentle pacing
    // AFRA Elegant: poised pitch, steady articulate cadence
    if (profile === 'afra-soft') {
      utterance.pitch = 1.15;
      utterance.rate = 0.95;
    } else {
      utterance.pitch = 1.05;
      utterance.rate = 1.0;
    }

    let ticker: any = null;

    utterance.onstart = () => {
      options.onStart?.();
      let phase = 0;
      ticker = setInterval(() => {
        phase += 0.28;
        const level = Math.abs(Math.sin(phase) * 0.5 + Math.cos(phase * 2.1) * 0.3) * 0.8;
        options.onAudioLevel?.(Math.min(1, Math.max(0.1, level)));
      }, 50);
    };

    const cleanup = () => {
      if (ticker) {
        clearInterval(ticker);
        ticker = null;
      }
      options.onAudioLevel?.(0);
    };

    utterance.onend = () => {
      cleanup();
      options.onEnd?.();
    };

    utterance.onerror = () => {
      cleanup();
      options.onError?.('SpeechSynthesis failed for female voice.');
    };

    window.speechSynthesis.speak(utterance);
  }

  // Test Voice Profile with real audio output
  public async testVoiceProfile(
    profileId: VoiceProfileId,
    isBangla: boolean = false,
    onAudioLevel?: (level: number) => void
  ): Promise<void> {
    const profile = VOICE_PROFILES[profileId];
    if (!profile) return;

    const sample = isBangla ? profile.testSampleBn : profile.testSampleEn;

    return new Promise((resolve, reject) => {
      this.speak(sample, {
        voiceProfile: profileId,
        onAudioLevel,
        onEnd: () => resolve(),
        onError: (err) => reject(new Error(err)),
      });
    });
  }

  // Real Microphone Listening with Web Audio Analyser
  public async startListening(
    onResult: (transcript: string, isFinal: boolean) => void,
    onAudioLevel: (level: number) => void,
    onError: (err: string) => void
  ): Promise<boolean> {
    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (!SpeechRecognition) {
      onError('Speech recognition is not supported in this browser. Please type your message.');
      return false;
    }

    try {
      if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
        try {
          const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
          this.mediaStream = stream;
          const ctx = this.initAudioContext();
          this.sourceNode = ctx.createMediaStreamSource(stream);
          this.analyser = ctx.createAnalyser();
          this.analyser.fftSize = 256;
          this.sourceNode.connect(this.analyser);

          const dataArray = new Uint8Array(this.analyser.frequencyBinCount);
          const trackLevel = () => {
            if (!this.analyser) return;
            this.analyser.getByteFrequencyData(dataArray);
            let sum = 0;
            for (let i = 0; i < dataArray.length; i++) {
              sum += dataArray[i];
            }
            const average = sum / dataArray.length;
            const normalized = Math.min(1, average / 80);
            onAudioLevel(normalized);

            if (this.mediaStream) {
              requestAnimationFrame(trackLevel);
            }
          };
          requestAnimationFrame(trackLevel);
        } catch (micErr) {
          console.warn('Microphone stream access for visualizer optional or denied:', micErr);
          this.synthInterval = window.setInterval(() => {
            onAudioLevel(0.3 + Math.random() * 0.4);
          }, 80);
        }
      }

      this.recognition = new SpeechRecognition();
      this.recognition.continuous = true;
      this.recognition.interimResults = true;
      this.recognition.lang = 'bn-BD';

      this.recognition.onresult = (event: any) => {
        let interim = '';
        let final = '';

        for (let i = event.resultIndex; i < event.results.length; ++i) {
          if (event.results[i].isFinal) {
            final += event.results[i][0].transcript;
          } else {
            interim += event.results[i][0].transcript;
          }
        }

        if (final) {
          onResult(final.trim(), true);
        } else if (interim) {
          onResult(interim.trim(), false);
        }
      };

      this.recognition.onerror = (event: any) => {
        console.warn('Speech recognition error:', event.error);
        if (event.error !== 'no-speech') {
          onError(event.error);
        }
      };

      this.recognition.start();
      return true;
    } catch (err: any) {
      onError(err?.message || 'Failed to start microphone');
      return false;
    }
  }

  public stopListening(): void {
    if (this.recognition) {
      try {
        this.recognition.stop();
      } catch (e) {}
      this.recognition = null;
    }

    if (this.mediaStream) {
      this.mediaStream.getTracks().forEach((t) => t.stop());
      this.mediaStream = null;
    }

    if (this.sourceNode) {
      this.sourceNode.disconnect();
      this.sourceNode = null;
    }

    if (this.synthInterval) {
      clearInterval(this.synthInterval);
      this.synthInterval = null;
    }
  }
}

export const SpeechAudioService = new AudioController();
