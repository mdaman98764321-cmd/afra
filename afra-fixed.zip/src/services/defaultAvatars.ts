import { AvatarItem } from '../types';

export const DEFAULT_AVATARS: AvatarItem[] = [
  {
    id: 'afra-core',
    name: 'AFRA Core',
    tagline: 'Flagship synthetic humanoid with brushed titanium and violet illumination',
    type: 'image',
    category: 'Core',
    imageUrl: '/src/assets/images/afra_core_portrait_1793966609177.jpg',
    tintColor: '#8b5cf6',
    glowIntensity: 0.85,
    breathingSpeed: 1.0,
    scaleFactor: 1.0,
    isBuiltIn: true,
    createdAt: 1740000000000,
  },
  {
    id: 'valkyrie-obsidian',
    name: 'Valkyrie Obsidian',
    tagline: 'High-precision android chassis with chrome armor and illuminated ocular visor',
    type: 'image',
    category: 'Humanoid',
    imageUrl: '/src/assets/images/afra_valkyrie_portrait_1793966610639.jpg',
    tintColor: '#a855f7',
    glowIntensity: 0.9,
    breathingSpeed: 0.9,
    scaleFactor: 1.05,
    isBuiltIn: true,
    createdAt: 1740000100000,
  },
  {
    id: 'quantum-singularity',
    name: 'Quantum Core',
    tagline: 'Luminescent energy nucleus surrounded by floating liquid chrome rings',
    type: 'image',
    category: 'Holographic',
    imageUrl: '/src/assets/images/afra_nebula_core_1793966609678.jpg',
    tintColor: '#06b6d4',
    glowIntensity: 0.95,
    breathingSpeed: 1.2,
    scaleFactor: 1.0,
    isBuiltIn: true,
    createdAt: 1740000200000,
  },
  {
    id: 'nexus-reactor',
    name: 'Nexus Reactor',
    tagline: 'Interactive 60fps HTML5 Canvas orbital rings reacting to voice frequencies',
    type: 'code',
    category: 'Holographic',
    tintColor: '#8b5cf6',
    glowIntensity: 0.9,
    breathingSpeed: 1.0,
    scaleFactor: 1.0,
    isBuiltIn: true,
    createdAt: 1740000300000,
    codeHtml: `<div class="reactor-container">
  <canvas id="c"></canvas>
  <div class="reactor-nucleus"></div>
</div>`,
    codeCss: `* { margin: 0; padding: 0; box-sizing: border-box; }
body {
  background: #0b0d10;
  overflow: hidden;
  display: flex;
  align-items: center;
  justify-content: center;
  height: 100vh;
  width: 100vw;
}
.reactor-container {
  position: relative;
  width: 280px;
  height: 280px;
  display: flex;
  align-items: center;
  justify-content: center;
}
#c {
  width: 100%;
  height: 100%;
}
.reactor-nucleus {
  position: absolute;
  width: 54px;
  height: 54px;
  border-radius: 50%;
  background: radial-gradient(circle, #ffffff 0%, var(--tint, #8b5cf6) 55%, transparent 75%);
  box-shadow: 0 0 35px var(--tint, #8b5cf6);
  pointer-events: none;
  transition: transform 0.2s cubic-bezier(0.16, 1, 0.3, 1);
}`,
    codeJs: `const canvas = document.getElementById('c');
const ctx = canvas.getContext('2d');
const nucleus = document.querySelector('.reactor-nucleus');

let state = 'idle';
let audioLevel = 0;
let tint = '#8b5cf6';
let angle = 0;

function resize() {
  const dpr = window.devicePixelRatio || 1;
  const rect = canvas.getBoundingClientRect();
  canvas.width = rect.width * dpr;
  canvas.height = rect.height * dpr;
  ctx.scale(dpr, dpr);
}
window.addEventListener('resize', resize);
resize();

window.addEventListener('message', (e) => {
  if (!e.data) return;
  if (e.data.state) state = e.data.state;
  if (typeof e.data.audioLevel === 'number') audioLevel = e.data.audioLevel;
  if (e.data.tint) {
    tint = e.data.tint;
    document.documentElement.style.setProperty('--tint', tint);
  }
});

function draw() {
  const width = canvas.clientWidth;
  const height = canvas.clientHeight;
  const cx = width / 2;
  const cy = height / 2;

  ctx.clearRect(0, 0, width, height);

  // Speed multiplier based on state
  let speed = 0.015;
  if (state === 'thinking') speed = 0.07;
  if (state === 'speaking') speed = 0.035 + (audioLevel * 0.04);
  if (state === 'listening') speed = 0.02 + (audioLevel * 0.02);

  angle += speed;

  const pulse = Math.sin(angle * 2) * 6;
  const reactiveScale = 1 + (audioLevel * 0.4);

  // Scale nucleus
  if (nucleus) {
    const nScale = state === 'speaking' ? 1 + audioLevel * 0.6 : (state === 'thinking' ? 1.15 + Math.sin(angle * 4) * 0.15 : 1);
    nucleus.style.transform = \`scale(\${nScale})\`;
  }

  // Draw concentric elliptical rings
  const ringCount = 3;
  for (let i = 0; i < ringCount; i++) {
    ctx.save();
    ctx.translate(cx, cy);
    const ringAngle = angle * (i % 2 === 0 ? 1 : -1) + (i * Math.PI / ringCount);
    ctx.rotate(ringAngle);

    ctx.beginPath();
    const rx = (70 + i * 26 + pulse) * reactiveScale;
    const ry = (32 + i * 16) * reactiveScale;
    ctx.ellipse(0, 0, rx, ry, 0, 0, Math.PI * 2);
    ctx.strokeStyle = i === 0 ? '#ffffff' : (i === 1 ? tint : '#94a3b8');
    ctx.lineWidth = i === 0 ? 2 : 1.5;
    ctx.shadowBlur = 16;
    ctx.shadowColor = tint;
    ctx.stroke();

    // Orbiter nodes
    const nodeAngle = angle * 2 + (i * 2);
    const nx = Math.cos(nodeAngle) * rx;
    const ny = Math.sin(nodeAngle) * ry;
    ctx.beginPath();
    ctx.arc(nx, ny, 3.5, 0, Math.PI * 2);
    ctx.fillStyle = '#ffffff';
    ctx.shadowBlur = 10;
    ctx.shadowColor = '#ffffff';
    ctx.fill();

    ctx.restore();
  }

  // Listening or speaking wave ripples
  if (state === 'listening' || state === 'speaking') {
    ctx.beginPath();
    const rippleR = (85 + (angle * 40) % 50) * reactiveScale;
    ctx.arc(cx, cy, rippleR, 0, Math.PI * 2);
    ctx.strokeStyle = state === 'listening' ? 'rgba(6, 182, 212, 0.4)' : 'rgba(139, 92, 246, 0.4)';
    ctx.lineWidth = 1;
    ctx.stroke();
  }

  requestAnimationFrame(draw);
}
requestAnimationFrame(draw);`,
  },
  {
    id: 'cyber-iris',
    name: 'Cyber Iris Matrix',
    tagline: 'Precision CSS3 animated cybernetic aperture with illuminated concentric focal blades',
    type: 'code',
    category: 'Minimalist',
    tintColor: '#06b6d4',
    glowIntensity: 0.88,
    breathingSpeed: 1.1,
    scaleFactor: 1.0,
    isBuiltIn: true,
    createdAt: 1740000400000,
    codeHtml: `<div class="iris-chassis">
  <div class="ring outer-ring"></div>
  <div class="ring mid-ring"></div>
  <div class="ring inner-ring"></div>
  <div class="core-pupil">
    <div class="pupil-glint"></div>
  </div>
  <div class="hud-marks"></div>
</div>`,
    codeCss: `* { margin: 0; padding: 0; box-sizing: border-box; }
body {
  background: #0b0d10;
  display: flex;
  align-items: center;
  justify-content: center;
  height: 100vh;
  width: 100vw;
  overflow: hidden;
}
.iris-chassis {
  position: relative;
  width: 240px;
  height: 240px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
}
.ring {
  position: absolute;
  border-radius: 50%;
  border: 1px solid rgba(255, 255, 255, 0.15);
  transition: all 0.3s cubic-bezier(0.16, 1, 0.3, 1);
}
.outer-ring {
  width: 220px;
  height: 220px;
  border: 1.5px dashed var(--tint, #06b6d4);
  animation: spin 24s linear infinite;
  box-shadow: 0 0 25px rgba(6, 182, 212, 0.2);
}
.mid-ring {
  width: 160px;
  height: 160px;
  border: 2px solid rgba(226, 232, 240, 0.3);
  border-top-color: var(--tint, #06b6d4);
  border-bottom-color: var(--tint, #06b6d4);
  animation: spin-rev 12s linear infinite;
}
.inner-ring {
  width: 100px;
  height: 100px;
  border: 1px solid rgba(255, 255, 255, 0.4);
  animation: breathe 3s ease-in-out infinite;
}
.core-pupil {
  width: 52px;
  height: 52px;
  border-radius: 50%;
  background: radial-gradient(circle, #ffffff 0%, var(--tint, #06b6d4) 60%, #0b0d10 95%);
  box-shadow: 0 0 30px var(--tint, #06b6d4);
  position: relative;
  transition: transform 0.15s ease-out;
}
.pupil-glint {
  position: absolute;
  top: 10px;
  left: 12px;
  width: 10px;
  height: 10px;
  border-radius: 50%;
  background: #ffffff;
  filter: blur(1px);
}
@keyframes spin {
  from { transform: rotate(0deg); }
  to { transform: rotate(360deg); }
}
@keyframes spin-rev {
  from { transform: rotate(360deg); }
  to { transform: rotate(0deg); }
}
@keyframes breathe {
  0%, 100% { transform: scale(1); opacity: 0.6; }
  50% { transform: scale(1.08); opacity: 0.9; }
}`,
    codeJs: `const pupil = document.querySelector('.core-pupil');
const midRing = document.querySelector('.mid-ring');
const outerRing = document.querySelector('.outer-ring');

window.addEventListener('message', (e) => {
  if (!e.data) return;
  const { state, audioLevel = 0, tint } = e.data;
  if (tint) {
    document.documentElement.style.setProperty('--tint', tint);
  }
  if (pupil) {
    if (state === 'speaking') {
      const scale = 1 + audioLevel * 0.7;
      pupil.style.transform = \`scale(\${scale})\`;
    } else if (state === 'listening') {
      pupil.style.transform = 'scale(1.25)';
    } else if (state === 'thinking') {
      pupil.style.transform = 'scale(0.85)';
    } else {
      pupil.style.transform = 'scale(1)';
    }
  }
  if (outerRing && state === 'thinking') {
    outerRing.style.animationDuration = '4s';
  } else if (outerRing) {
    outerRing.style.animationDuration = '24s';
  }
});`,
  },
];
