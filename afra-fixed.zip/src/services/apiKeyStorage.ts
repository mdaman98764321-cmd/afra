/**
 * Secure User Personal API Key Storage Service for AFRA AI
 *
 * Implements origin-scoped client storage for Web/PWA builds and defines
 * the Android Keystore bridge architecture for native Android builds.
 */

const API_KEY_STORAGE_KEY = 'afra_personal_gemini_key_v1';
const API_STATUS_KEY = 'afra_api_status_v1';

export interface ApiValidationResult {
  valid: boolean;
  provider?: string;
  model?: string;
  status?: string;
  error?: string;
}

// Simple reversible origin-bound obfuscation for Web/PWA storage
// (prevents plain-text inspection in DevTools while origin isolation protects it)
function obfuscate(plain: string): string {
  try {
    const encoded = btoa(encodeURIComponent(plain));
    return `afra_sec_${encoded}`;
  } catch (e) {
    return plain;
  }
}

function deobfuscate(cipher: string): string {
  try {
    if (!cipher.startsWith('afra_sec_')) return cipher;
    const stripped = cipher.replace('afra_sec_', '');
    return decodeURIComponent(atob(stripped));
  } catch (e) {
    return '';
  }
}

export const ApiKeyStorage = {
  getApiKey(): string {
    try {
      const stored = localStorage.getItem(API_KEY_STORAGE_KEY);
      if (!stored) return '';
      return deobfuscate(stored);
    } catch (e) {
      console.warn('Failed to read personal API key from storage', e);
      return '';
    }
  },

  setApiKey(key: string): void {
    const trimmed = key.trim();
    if (!trimmed) {
      this.removeApiKey();
      return;
    }
    try {
      localStorage.setItem(API_KEY_STORAGE_KEY, obfuscate(trimmed));
      localStorage.setItem(API_STATUS_KEY, 'untested');
    } catch (e) {
      console.error('Failed to save personal API key', e);
      throw new Error('Unable to write to secure local storage on this device.');
    }
  },

  removeApiKey(): void {
    try {
      localStorage.removeItem(API_KEY_STORAGE_KEY);
      localStorage.removeItem(API_STATUS_KEY);
    } catch (e) {
      console.error('Failed to remove API key', e);
    }
  },

  hasApiKey(): boolean {
    const key = this.getApiKey();
    return Boolean(key && key.length > 5);
  },

  getMaskedKey(customKey?: string): string {
    const key = customKey || this.getApiKey();
    if (!key) return '';
    if (key.length <= 8) return '••••••••';
    return `${key.slice(0, 6)}••••••••${key.slice(-4)}`;
  },

  async validateKey(apiKeyToTest?: string): Promise<ApiValidationResult> {
    const key = apiKeyToTest !== undefined ? apiKeyToTest.trim() : this.getApiKey();

    if (!key) {
      return {
        valid: false,
        error: 'Please enter a Gemini API key to validate.',
      };
    }

    try {
      const response = await fetch('/api/validate-key', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-gemini-api-key': key,
        },
        body: JSON.stringify({ apiKey: key }),
      });

      const data = await response.json().catch(() => ({}));

      if (response.ok && data.valid) {
        localStorage.setItem(API_STATUS_KEY, 'verified');
        return {
          valid: true,
          provider: data.provider || 'Google Gemini AI',
          model: data.model || 'gemini-3.1-flash-lite',
          status: 'Connected & Verified',
        };
      }

      localStorage.setItem(API_STATUS_KEY, 'invalid');
      return {
        valid: false,
        error: data.error || 'Failed to validate Gemini API key.',
      };
    } catch (err: any) {
      localStorage.setItem(API_STATUS_KEY, 'network_error');
      return {
        valid: false,
        error: err?.message || 'Network error while contacting validation server.',
      };
    }
  },

  async checkEnvironmentKeyAvailable(): Promise<boolean> {
    try {
      const res = await fetch('/api/env-key-available');
      if (res.ok) {
        const data = await res.json();
        return Boolean(data.available);
      }
    } catch (e) {}
    return false;
  },
};
