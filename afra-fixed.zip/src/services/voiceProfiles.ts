import { VoiceProfileConfig, VoiceProfileId } from '../types';

export const VOICE_PROFILES: Record<VoiceProfileId, VoiceProfileConfig> = {
  'afra-soft': {
    id: 'afra-soft',
    name: 'AFRA Soft',
    tagline: 'Soft, sweet, warm and friendly with gentle conversational delivery',
    characteristics: [
      'Natural feminine voice',
      'Soft & sweet acoustic timbre',
      'Warm & friendly delivery',
      'Natural Bangla & Banglish pronunciation',
    ],
    geminiVoice: 'Zephyr',
    promptStyle:
      'Soft, sweet, warm and friendly feminine voice with gentle conversational delivery and natural Bangla and Banglish pronunciation.',
    testSampleEn:
      'Hello, I am AFRA Soft. A warm and gentle feminine voice crafted for calm, friendly conversation.',
    testSampleBn:
      'নমস্কার, কেমন আছেন? আমি আফরা সফট। মিষ্টি ও বন্ধুসুলভ কণ্ঠে আপনার সাথে কথা বলতে প্রস্তুত।',
  },
  'afra-elegant': {
    id: 'afra-elegant',
    name: 'AFRA Elegant',
    tagline: 'Clear, elegant, confident and expressive with a refined tone',
    characteristics: [
      'Natural feminine voice',
      'Clear, articulate & poised',
      'Confident, slightly mature tone',
      'Natural Bangla & English pronunciation',
    ],
    geminiVoice: 'Kore',
    promptStyle:
      'Clear, elegant, confident and expressive feminine voice with a refined, slightly mature conversational tone and natural Bangla and English pronunciation.',
    testSampleEn:
      'Greetings. I am AFRA Elegant. Articulate, poised, and engineered for sophisticated executive dialogue.',
    testSampleBn:
      'স্বাগতম। আমি আফরা এলিগ্যান্ট। স্পষ্ট ও আত্মবিশ্বাসী কণ্ঠে আপনার সহায়তায় নিয়োজিত।',
  },
};
