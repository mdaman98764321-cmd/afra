export type AvatarType = 'image' | 'canvas' | 'code';
export type AvatarState = 'idle' | 'listening' | 'thinking' | 'speaking' | 'happy' | 'error';

export interface AvatarItem {
  id: string;
  name: string;
  tagline: string;
  type: AvatarType;
  category: 'Core' | 'Humanoid' | 'Holographic' | 'Minimalist' | 'Custom';
  imageUrl?: string;
  codeHtml?: string;
  codeCss?: string;
  codeJs?: string;
  // Unified single code block for iframe execution
  bundledCode?: string;
  tintColor: string;
  glowIntensity: number; // 0 to 1
  breathingSpeed: number; // 0.5 to 2.0
  scaleFactor: number; // 0.8 to 1.3
  isBuiltIn: boolean;
  createdAt: number;
}

export type ChatRole = 'user' | 'assistant';

export interface ChatMessage {
  id: string;
  role: ChatRole;
  content: string;
  timestamp: number;
  avatarState?: AvatarState;
  isStreaming?: boolean;
}

export type PersonaMode = 'balanced' | 'creative' | 'precise' | 'technical';

export type AppTheme = 'obsidian' | 'charcoal' | 'violet-noir' | 'silver-edge';

export type VoiceProfileId = 'afra-soft' | 'afra-elegant';

export interface VoiceProfileConfig {
  id: VoiceProfileId;
  name: string;
  tagline: string;
  characteristics: string[];
  geminiVoice: 'Zephyr' | 'Kore';
  promptStyle: string;
  testSampleEn: string;
  testSampleBn: string;
}

export interface AppSettings {
  theme: AppTheme;
  personaMode: PersonaMode;
  customPersona: string;
  voiceProfile: VoiceProfileId;
  speechVoiceName: string;
  speechRate: number; // 0.8 to 1.5
  speechPitch: number; // 0.8 to 1.3
  hapticFeedback: boolean;
  soundEffects: boolean;
  autoSpeakResponse: boolean;
  showStateControls: boolean;
}

export interface AndroidBridgeEvent {
  action: 'onStateChange' | 'onSpeechRecognized' | 'onTTSComplete' | 'onAvatarSelected';
  payload: Record<string, any>;
  timestamp: number;
}
