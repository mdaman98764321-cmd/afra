import React, { useState } from 'react';
import { SettingsProvider } from './context/SettingsContext';
import { AvatarEngineProvider, useAvatarEngine } from './context/AvatarEngineContext';
import { ConversationProvider, useConversation } from './context/ConversationContext';
import { TopNav } from './components/layout/TopNav';
import { MobileTabBar } from './components/layout/MobileTabBar';
import { ChatInterface } from './components/chat/ChatInterface';
import { AvatarStudio } from './components/studio/AvatarStudio';
import { FloatingOverlayStudio } from './components/overlay/FloatingOverlayStudio';
import { SettingsView } from './components/settings/SettingsView';
import { VoiceAssistantOverlay } from './components/voice/VoiceAssistantOverlay';
import { AvatarRenderer } from './components/avatar/AvatarRenderer';
import { StateSimulationController } from './components/avatar/StateSimulationController';
import { Mic, Sparkles, Sliders, ChevronRight, Layers } from 'lucide-react';

function AppContent() {
  const [activeView, setActiveView] = useState<'chat' | 'studio' | 'overlay' | 'settings'>('chat');
  const { setVoiceOverlayOpen } = useConversation();
  const { activeAvatar, avatarState, audioLevel, setAvatarState, setAudioLevel } = useAvatarEngine();

  return (
    <div className="flex flex-col h-screen w-screen bg-[#0b0d10] text-[#e2e8f0] overflow-hidden select-none">
      {/* Universal Top Bar */}
      <TopNav
        activeView={activeView}
        onSelectView={setActiveView}
        onOpenVoice={() => setVoiceOverlayOpen(true)}
      />

      {/* Main Content Area */}
      <main className="flex-1 flex overflow-hidden relative pb-16 md:pb-0">
        {activeView === 'chat' && (
          <div className="flex-1 flex overflow-hidden w-full">
            {/* Primary Chat Interface */}
            <div className="flex-1 flex flex-col h-full overflow-hidden border-r border-slate-800/80">
              <ChatInterface onNavigateToSettings={() => setActiveView('settings')} />
            </div>

            {/* Desktop Side Kinetic Avatar Stage (hidden on mobile, visible on lg screens) */}
            <aside className="hidden lg:flex flex-col w-80 xl:w-96 p-6 bg-slate-950/70 overflow-y-auto space-y-6">
              <div className="flex items-center justify-between">
                <span className="text-xs uppercase tracking-wider text-slate-400 font-medium">
                  Avatar Presence Stage
                </span>
                <span className="text-xs text-violet-400 font-mono capitalize">
                  {avatarState}
                </span>
              </div>

              {/* Central Kinetic Avatar Viewport */}
              <div className="flex flex-col items-center justify-center p-6 rounded-3xl bg-slate-900/60 border border-slate-800/80 shadow-2xl">
                <AvatarRenderer
                  avatar={activeAvatar}
                  state={avatarState}
                  audioLevel={audioLevel}
                  size="md"
                  showHalo={true}
                />

                <div className="text-center mt-5">
                  <h3 className="text-base font-semibold text-white font-display">
                    {activeAvatar.name}
                  </h3>
                  <p className="text-xs text-slate-400 mt-1 line-clamp-2">
                    {activeAvatar.tagline}
                  </p>
                </div>

                <button
                  onClick={() => setActiveView('studio')}
                  className="flex items-center gap-1.5 mt-4 text-xs font-medium text-violet-400 hover:text-violet-300 transition-colors"
                >
                  <span>Customize in Studio</span>
                  <ChevronRight className="w-3.5 h-3.5" />
                </button>
              </div>

              {/* Interactive State Simulation Dock */}
              <div className="w-full">
                <StateSimulationController
                  currentState={avatarState}
                  audioLevel={audioLevel}
                  onStateChange={setAvatarState}
                  onAudioLevelChange={setAudioLevel}
                />
              </div>

              {/* Quick Voice Assistant Trigger */}
              <button
                onClick={() => setVoiceOverlayOpen(true)}
                className="w-full flex items-center justify-center gap-2 py-3 px-4 rounded-2xl bg-gradient-to-r from-violet-600 to-indigo-600 hover:from-violet-500 hover:to-indigo-500 text-white text-xs font-semibold shadow-lg shadow-violet-600/25 active:scale-[0.98] transition-all"
              >
                <Mic className="w-4 h-4" />
                <span>Enter Full-Screen Voice Mode</span>
              </button>

              {/* Quick Android Overlay Studio Link */}
              <button
                onClick={() => setActiveView('overlay')}
                className="w-full flex items-center justify-center gap-2 py-2.5 px-4 rounded-2xl bg-slate-900/90 hover:bg-slate-800 border border-slate-800 text-slate-300 hover:text-white text-xs font-medium transition-all"
              >
                <Layers className="w-3.5 h-3.5 text-cyan-400" />
                <span>Test Floating Overlay Studio</span>
              </button>
            </aside>
          </div>
        )}

        {activeView === 'studio' && <AvatarStudio />}

        {activeView === 'overlay' && (
          <FloatingOverlayStudio onNavigateToChat={() => setActiveView('chat')} />
        )}

        {activeView === 'settings' && <SettingsView />}
      </main>

      {/* Voice Assistant Fullscreen Overlay */}
      <VoiceAssistantOverlay />

      {/* Mobile Fixed Bottom Navigation Bar */}
      <MobileTabBar
        activeView={activeView}
        onSelectView={setActiveView}
        onOpenVoice={() => setVoiceOverlayOpen(true)}
      />
    </div>
  );
}

export default function App() {
  return (
    <SettingsProvider>
      <AvatarEngineProvider>
        <ConversationProvider>
          <AppContent />
        </ConversationProvider>
      </AvatarEngineProvider>
    </SettingsProvider>
  );
}
