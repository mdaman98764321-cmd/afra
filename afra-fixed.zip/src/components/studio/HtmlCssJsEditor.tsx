import React, { useState } from 'react';
import { useAvatarEngine } from '../../context/AvatarEngineContext';
import { AvatarItem, AvatarState } from '../../types';
import { SandboxIframe } from '../avatar/SandboxIframe';
import { StateSimulationController } from '../avatar/StateSimulationController';
import { ChatApiService } from '../../services/chatApi';
import {
  ArrowLeft,
  Check,
  Code,
  Sparkles,
  Layers,
  Wand2,
  RefreshCw,
  Play,
  Sliders,
} from 'lucide-react';

interface HtmlCssJsEditorProps {
  initialAvatar?: AvatarItem;
  onBack: () => void;
}

const TEMPLATES = [
  {
    name: 'Nexus Reactor (Canvas)',
    html: `<div class="reactor"><canvas id="c"></canvas></div>`,
    css: `* { margin:0; padding:0; }
body { background:#0b0d10; display:flex; align-items:center; justify-content:center; height:100vh; overflow:hidden; }
.reactor { width:260px; height:260px; position:relative; }
#c { width:100%; height:100%; }`,
    js: `const canvas = document.getElementById('c');
const ctx = canvas.getContext('2d');
let state = 'idle', audioLevel = 0, angle = 0;
function resize() {
  const dpr = window.devicePixelRatio || 1;
  canvas.width = canvas.clientWidth * dpr;
  canvas.height = canvas.clientHeight * dpr;
  ctx.scale(dpr, dpr);
}
resize();
window.addEventListener('resize', resize);
window.addEventListener('message', (e) => {
  if (e.data?.state) state = e.data.state;
  if (typeof e.data?.audioLevel === 'number') audioLevel = e.data.audioLevel;
});
function loop() {
  const w = canvas.clientWidth, h = canvas.clientHeight;
  ctx.clearRect(0, 0, w, h);
  angle += (state === 'thinking' ? 0.08 : 0.02) + (audioLevel * 0.03);
  ctx.save();
  ctx.translate(w/2, h/2);
  for (let i = 0; i < 3; i++) {
    ctx.rotate(angle + i);
    ctx.beginPath();
    ctx.arc(0, 0, (60 + i * 20) * (1 + audioLevel * 0.3), 0, Math.PI * 1.5);
    ctx.strokeStyle = i === 1 ? '#8b5cf6' : (i === 2 ? '#06b6d4' : '#e2e8f0');
    ctx.lineWidth = 2;
    ctx.shadowBlur = 12;
    ctx.shadowColor = '#8b5cf6';
    ctx.stroke();
  }
  ctx.restore();
  requestAnimationFrame(loop);
}
requestAnimationFrame(loop);`,
  },
  {
    name: 'Cyber Iris (CSS3)',
    html: `<div class="iris"><div class="blade outer"></div><div class="blade inner"></div><div class="pupil"></div></div>`,
    css: `* { margin: 0; box-sizing: border-box; }
body { background: #0b0d10; display:flex; align-items:center; justify-content:center; height:100vh; overflow:hidden; }
.iris { position:relative; width:220px; height:220px; display:flex; align-items:center; justify-content:center; }
.blade { position:absolute; border-radius:50%; }
.outer { width:210px; height:210px; border:2px dashed #8b5cf6; animation: rot 20s linear infinite; }
.inner { width:140px; height:140px; border:2px solid #06b6d4; animation: rot-rev 10s linear infinite; }
.pupil { width:48px; height:48px; border-radius:50%; background:radial-gradient(circle, #fff, #8b5cf6 60%, transparent); box-shadow:0 0 25px #8b5cf6; transition:transform 0.15s ease-out; }
@keyframes rot { from { transform:rotate(0deg); } to { transform:rotate(360deg); } }
@keyframes rot-rev { from { transform:rotate(360deg); } to { transform:rotate(0deg); } }`,
    js: `const pupil = document.querySelector('.pupil');
window.addEventListener('message', (e) => {
  const { state, audioLevel = 0 } = e.data || {};
  if (pupil) {
    const scale = state === 'speaking' ? 1 + audioLevel * 0.8 : (state === 'listening' ? 1.25 : 1);
    pupil.style.transform = \`scale(\${scale})\`;
  }
});`,
  },
  {
    name: 'Quantum Sine Wave (Canvas)',
    html: `<div class="wave-box"><canvas id="c"></canvas></div>`,
    css: `body { background: #0b0d10; display: flex; align-items: center; justify-content: center; height: 100vh; margin: 0; }
.wave-box { width: 280px; height: 280px; }
canvas { width: 100%; height: 100%; }`,
    js: `const canvas = document.getElementById('c');
const ctx = canvas.getContext('2d');
let step = 0, state = 'idle', audioLevel = 0;
function resize() {
  canvas.width = canvas.clientWidth * (window.devicePixelRatio || 1);
  canvas.height = canvas.clientHeight * (window.devicePixelRatio || 1);
  ctx.scale(window.devicePixelRatio || 1, window.devicePixelRatio || 1);
}
resize();
window.addEventListener('message', (e) => {
  if (e.data?.state) state = e.data.state;
  if (typeof e.data?.audioLevel === 'number') audioLevel = e.data.audioLevel;
});
function draw() {
  const w = canvas.clientWidth, h = canvas.clientHeight;
  ctx.clearRect(0, 0, w, h);
  step += state === 'thinking' ? 0.08 : 0.03;
  ctx.beginPath();
  for (let x = 0; x < w; x += 3) {
    const freq = 0.025;
    const amp = (18 + audioLevel * 40) * (state === 'speaking' ? 1.4 : 1);
    const y = h/2 + Math.sin(x * freq + step) * amp * Math.sin(x / w * Math.PI);
    if (x === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
  }
  ctx.strokeStyle = state === 'listening' ? '#06b6d4' : '#8b5cf6';
  ctx.lineWidth = 2.5;
  ctx.shadowBlur = 15;
  ctx.shadowColor = ctx.strokeStyle;
  ctx.stroke();
  requestAnimationFrame(draw);
}
requestAnimationFrame(draw);`,
  },
];

export const HtmlCssJsEditor: React.FC<HtmlCssJsEditorProps> = ({ initialAvatar, onBack }) => {
  const { saveCustomAvatar } = useAvatarEngine();

  const [activeTab, setActiveTab] = useState<'html' | 'css' | 'js'>('js');
  const [name, setName] = useState(initialAvatar?.name || 'Cyber Singularity');
  const [tagline, setTagline] = useState(
    initialAvatar?.tagline || 'Interactive generative code avatar reactive to voice states'
  );
  const [htmlCode, setHtmlCode] = useState(
    initialAvatar?.codeHtml || TEMPLATES[0].html
  );
  const [cssCode, setCssCode] = useState(
    initialAvatar?.codeCss || TEMPLATES[0].css
  );
  const [jsCode, setJsCode] = useState(
    initialAvatar?.codeJs || TEMPLATES[0].js
  );
  const [tintColor, setTintColor] = useState(initialAvatar?.tintColor || '#8b5cf6');

  // Simulation test states inside the editor
  const [testState, setTestState] = useState<AvatarState>('idle');
  const [testAudioLevel, setTestAudioLevel] = useState<number>(0);

  // AI Prompt generation state
  const [aiPrompt, setAiPrompt] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [genError, setGenError] = useState<string | null>(null);

  const handleApplyTemplate = (tmpl: (typeof TEMPLATES)[0]) => {
    setHtmlCode(tmpl.html);
    setCssCode(tmpl.css);
    setJsCode(tmpl.js);
  };

  const handleGenerateAiCode = async () => {
    if (!aiPrompt.trim() || isGenerating) return;
    setIsGenerating(true);
    setGenError(null);

    try {
      const generatedCode = await ChatApiService.generateAvatarCode(aiPrompt.trim());
      // The generated code is usually a unified document or script.
      // We can inspect or split it into html, style, script
      const parser = new DOMParser();
      const doc = parser.parseFromString(generatedCode, 'text/html');

      const style = doc.querySelector('style')?.textContent || '';
      const script = doc.querySelector('script')?.textContent || '';
      doc.querySelector('style')?.remove();
      doc.querySelector('script')?.remove();
      const bodyHtml = doc.body.innerHTML || generatedCode;

      if (style || script) {
        setHtmlCode(bodyHtml.trim());
        if (style) setCssCode(style.trim());
        if (script) setJsCode(script.trim());
      } else {
        // If pure JS or snippet
        setJsCode(generatedCode);
      }
      setAiPrompt('');
    } catch (err: any) {
      setGenError(err?.message || 'Failed to generate avatar code');
    } finally {
      setIsGenerating(false);
    }
  };

  const handleSave = () => {
    const avatarToSave: AvatarItem = {
      id: initialAvatar ? initialAvatar.id : `custom-code-${Date.now()}`,
      name: name.trim() || 'Untitled Code Avatar',
      tagline: tagline.trim() || 'Custom HTML/CSS/JS Sandbox Avatar',
      type: 'code',
      category: 'Custom',
      codeHtml: htmlCode,
      codeCss: cssCode,
      codeJs: jsCode,
      tintColor,
      glowIntensity: 0.9,
      breathingSpeed: 1.0,
      scaleFactor: 1.0,
      isBuiltIn: false,
      createdAt: initialAvatar ? initialAvatar.createdAt : Date.now(),
    };

    saveCustomAvatar(avatarToSave);
    onBack();
  };

  return (
    <div className="space-y-6 max-w-6xl mx-auto">
      {/* Top Bar Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <button
          onClick={onBack}
          className="flex items-center gap-2 text-xs font-medium text-slate-400 hover:text-white transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Gallery</span>
        </button>

        <div className="flex items-center gap-3">
          <button
            onClick={handleSave}
            className="flex items-center gap-1.5 px-4 py-2 text-xs font-medium bg-violet-600 hover:bg-violet-500 text-white rounded-xl shadow-md shadow-violet-600/30 transition-all active:scale-95"
          >
            <Check className="w-3.5 h-3.5" />
            <span>Save to Gallery & Activate</span>
          </button>
        </div>
      </div>

      {/* AI Generator Quick Bar */}
      <div className="p-4 rounded-2xl bg-gradient-to-r from-slate-900 via-slate-900 to-slate-950 border border-violet-500/30 shadow-lg">
        <div className="flex items-center justify-between gap-2 mb-2">
          <div className="flex items-center gap-2">
            <Wand2 className="w-4 h-4 text-violet-400" />
            <span className="text-xs font-semibold text-white font-display">
              AI Avatar Code Synthesizer
            </span>
          </div>
          <span className="text-[11px] text-slate-400">Powered by Gemini 3.8</span>
        </div>

        <div className="flex flex-col sm:flex-row items-center gap-2">
          <input
            type="text"
            value={aiPrompt}
            onChange={(e) => setAiPrompt(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleGenerateAiCode()}
            placeholder="Describe an avatar (e.g. 'Concentric glowing titanium rings with soundwave audio reactivity')..."
            className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-violet-500 transition-colors"
          />
          <button
            onClick={handleGenerateAiCode}
            disabled={!aiPrompt.trim() || isGenerating}
            className={`w-full sm:w-auto shrink-0 flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl text-xs font-medium text-white transition-all ${
              aiPrompt.trim() && !isGenerating
                ? 'bg-violet-600 hover:bg-violet-500 shadow-md shadow-violet-600/30'
                : 'bg-slate-800 text-slate-500 cursor-not-allowed'
            }`}
          >
            {isGenerating ? (
              <>
                <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                <span>Generating...</span>
              </>
            ) : (
              <>
                <Sparkles className="w-3.5 h-3.5" />
                <span>Generate Code</span>
              </>
            )}
          </button>
        </div>

        {genError && (
          <p className="text-xs text-rose-400 mt-2 bg-rose-950/40 p-2 rounded-lg border border-rose-900/50">
            {genError}
          </p>
        )}
      </div>

      {/* Editor & Preview Split Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left Column: Code Editor (7 cols) */}
        <div className="lg:col-span-7 space-y-4">
          {/* Identity & Template Bar */}
          <div className="p-4 rounded-2xl bg-slate-900/70 border border-slate-800/80 space-y-3">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-[11px] font-medium text-slate-400 mb-1">
                  Avatar Name
                </label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-800 text-xs text-slate-200 focus:outline-none focus:border-violet-500"
                />
              </div>
              <div>
                <label className="block text-[11px] font-medium text-slate-400 mb-1">
                  Tagline / Description
                </label>
                <input
                  type="text"
                  value={tagline}
                  onChange={(e) => setTagline(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-800 text-xs text-slate-200 focus:outline-none focus:border-violet-500"
                />
              </div>
            </div>

            {/* Template Presets Picker */}
            <div className="flex items-center gap-2 pt-2 border-t border-slate-800/60 overflow-x-auto scrollbar-none">
              <span className="text-[11px] text-slate-500 shrink-0">Templates:</span>
              {TEMPLATES.map((tmpl) => (
                <button
                  key={tmpl.name}
                  type="button"
                  onClick={() => handleApplyTemplate(tmpl)}
                  className="px-2.5 py-1 text-[11px] font-medium text-slate-300 hover:text-white bg-slate-800/80 hover:bg-slate-700 rounded-md transition-colors whitespace-nowrap"
                >
                  {tmpl.name}
                </button>
              ))}
            </div>
          </div>

          {/* Code Tabs & Textarea */}
          <div className="rounded-2xl bg-slate-950 border border-slate-800 overflow-hidden shadow-2xl">
            {/* Tab Header */}
            <div className="flex items-center justify-between px-4 py-2.5 bg-slate-900/90 border-b border-slate-800">
              <div className="flex items-center gap-1">
                {(['html', 'css', 'js'] as const).map((tab) => (
                  <button
                    key={tab}
                    onClick={() => setActiveTab(tab)}
                    className={`px-3 py-1 text-xs font-mono font-medium rounded-md uppercase transition-colors ${
                      activeTab === tab
                        ? 'bg-slate-800 text-violet-400 border border-slate-700'
                        : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    {tab}
                  </button>
                ))}
              </div>

              <div className="text-[11px] text-slate-500 font-mono">
                PostMessage API: state, audioLevel, tint
              </div>
            </div>

            {/* Code Textarea with Dark Monospace styling */}
            <div className="relative p-2">
              <textarea
                value={
                  activeTab === 'html'
                    ? htmlCode
                    : activeTab === 'css'
                    ? cssCode
                    : jsCode
                }
                onChange={(e) => {
                  const val = e.target.value;
                  if (activeTab === 'html') setHtmlCode(val);
                  else if (activeTab === 'css') setCssCode(val);
                  else setJsCode(val);
                }}
                rows={16}
                spellCheck={false}
                className="w-full bg-transparent font-mono text-xs leading-relaxed text-slate-200 p-2 focus:outline-none resize-y selection:bg-violet-500/30"
              />
            </div>
          </div>
        </div>

        {/* Right Column: Live Sandbox Preview & State Testing (5 cols) */}
        <div className="lg:col-span-5 space-y-4">
          <div className="p-6 rounded-3xl bg-slate-900/70 border border-slate-800/80 shadow-2xl flex flex-col items-center">
            <div className="w-full flex items-center justify-between mb-4">
              <span className="text-xs uppercase tracking-wider text-slate-400 font-medium">
                Live Isolated Sandbox
              </span>
              <span className="text-[11px] text-violet-400 font-mono">60 FPS</span>
            </div>

            {/* Sandbox Canvas / Iframe Viewport */}
            <div className="relative w-64 h-64 sm:w-72 sm:h-72 rounded-2xl overflow-hidden border border-slate-800 bg-[#0b0d10] shadow-inner flex items-center justify-center">
              <SandboxIframe
                codeHtml={htmlCode}
                codeCss={cssCode}
                codeJs={jsCode}
                state={testState}
                audioLevel={testAudioLevel}
                tintColor={tintColor}
                className="w-full h-full"
              />
            </div>

            {/* State Simulation Controls */}
            <div className="w-full mt-6">
              <StateSimulationController
                currentState={testState}
                audioLevel={testAudioLevel}
                onStateChange={setTestState}
                onAudioLevelChange={setTestAudioLevel}
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
