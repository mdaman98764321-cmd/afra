import React, { useState } from 'react';
import { AvatarItem } from '../../types';
import { AvatarGallery } from './AvatarGallery';
import { ImageAvatarImporter } from './ImageAvatarImporter';
import { HtmlCssJsEditor } from './HtmlCssJsEditor';
import { AvatarStateManager } from './AvatarStateManager';
import { Grid, Image, Code, Cpu } from 'lucide-react';

export const AvatarStudio: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'gallery' | 'importer' | 'editor' | 'state-manager'>(
    'gallery'
  );
  const [editingAvatar, setEditingAvatar] = useState<AvatarItem | undefined>(undefined);

  const handleOpenEditor = (avatar?: AvatarItem) => {
    setEditingAvatar(avatar);
    setActiveTab('editor');
  };

  const tabs = [
    { id: 'gallery', label: 'Gallery', icon: <Grid className="w-3.5 h-3.5" /> },
    { id: 'importer', label: 'Image Importer', icon: <Image className="w-3.5 h-3.5" /> },
    { id: 'editor', label: 'HTML/CSS/JS Editor', icon: <Code className="w-3.5 h-3.5" /> },
    { id: 'state-manager', label: 'State Manager', icon: <Cpu className="w-3.5 h-3.5" /> },
  ] as const;

  return (
    <div className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8 space-y-6 max-w-7xl mx-auto w-full">
      {/* Studio Segmented Navigation Header */}
      <div className="flex items-center gap-1.5 p-1 bg-slate-900/90 rounded-2xl border border-slate-800/80 w-full sm:w-fit overflow-x-auto scrollbar-none">
        {tabs.map((tab) => {
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => {
                if (tab.id !== 'editor') setEditingAvatar(undefined);
                setActiveTab(tab.id);
              }}
              className={`flex items-center gap-2 px-3.5 py-2 text-xs font-medium rounded-xl transition-all whitespace-nowrap ${
                isActive
                  ? 'bg-slate-800 text-white shadow-sm border border-slate-700/80'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/40'
              }`}
            >
              <span className={isActive ? 'text-violet-400' : 'text-slate-400'}>
                {tab.icon}
              </span>
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* View Switcher */}
      {activeTab === 'gallery' && (
        <AvatarGallery
          onOpenImporter={() => setActiveTab('importer')}
          onOpenEditor={handleOpenEditor}
        />
      )}

      {activeTab === 'importer' && (
        <ImageAvatarImporter onBack={() => setActiveTab('gallery')} />
      )}

      {activeTab === 'editor' && (
        <HtmlCssJsEditor
          initialAvatar={editingAvatar}
          onBack={() => {
            setEditingAvatar(undefined);
            setActiveTab('gallery');
          }}
        />
      )}

      {activeTab === 'state-manager' && <AvatarStateManager />}
    </div>
  );
};
