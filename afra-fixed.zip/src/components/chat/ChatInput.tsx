import React, { useState, useRef, useEffect } from 'react';
import { Send, Mic, MicOff, Sparkles } from 'lucide-react';
import { PersonaMode } from '../../types';

interface ChatInputProps {
  onSendMessage: (text: string) => void;
  onVoiceTrigger: () => void;
  isListening: boolean;
  isThinking: boolean;
  personaMode: PersonaMode;
  onPersonaChange: (mode: PersonaMode) => void;
}

export const ChatInput: React.FC<ChatInputProps> = ({
  onSendMessage,
  onVoiceTrigger,
  isListening,
  isThinking,
  personaMode,
  onPersonaChange,
}) => {
  const [text, setText] = useState('');
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  const handleSubmit = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!text.trim() || isThinking) return;
    onSendMessage(text);
    setText('');
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSubmit();
    }
  };

  const adjustHeight = () => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = `${Math.min(textareaRef.current.scrollHeight, 140)}px`;
    }
  };

  const modes: { id: PersonaMode; label: string }[] = [
    { id: 'balanced', label: 'Balanced' },
    { id: 'creative', label: 'Creative' },
    { id: 'precise', label: 'Precise' },
    { id: 'technical', label: 'Technical' },
  ];

  return (
    <div className="w-full bg-[#0b0d10]/95 backdrop-blur-lg border-t border-slate-800/80 p-3 pb-safe sm:p-4">
      {/* Mode Selector Row */}
      <div className="flex items-center justify-between gap-2 mb-2 max-w-4xl mx-auto px-1">
        <div className="flex items-center gap-1.5 overflow-x-auto scrollbar-none py-0.5">
          {modes.map((m) => {
            const isActive = personaMode === m.id;
            return (
              <button
                key={m.id}
                type="button"
                onClick={() => onPersonaChange(m.id)}
                className={`text-[11px] font-medium px-2.5 py-1 rounded-md transition-colors whitespace-nowrap ${
                  isActive
                    ? 'bg-slate-800 text-white border border-slate-700/80'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {m.label}
              </button>
            );
          })}
        </div>

        <div className="hidden sm:flex items-center gap-1 text-[11px] text-slate-500">
          <Sparkles className="w-3 h-3 text-violet-400" />
          <span>AFRA v1.0</span>
        </div>
      </div>

      {/* Input Form Box */}
      <form
        onSubmit={handleSubmit}
        className="max-w-4xl mx-auto flex items-end gap-2 bg-slate-900/90 rounded-2xl p-2 border border-slate-800 shadow-xl focus-within:border-slate-700 transition-colors"
      >
        <button
          type="button"
          onClick={onVoiceTrigger}
          title={isListening ? 'Stop listening' : 'Start voice mode'}
          className={`shrink-0 w-11 h-11 rounded-xl flex items-center justify-center transition-all ${
            isListening
              ? 'bg-cyan-500 text-white shadow-lg shadow-cyan-500/25 animate-pulse'
              : 'text-slate-400 hover:text-white hover:bg-slate-800/80'
          }`}
        >
          {isListening ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
        </button>

        <textarea
          ref={textareaRef}
          rows={1}
          value={text}
          onChange={(e) => {
            setText(e.target.value);
            adjustHeight();
          }}
          onKeyDown={handleKeyDown}
          placeholder="Message AFRA... (Enter to send, Shift+Enter for newline)"
          className="w-full max-h-36 bg-transparent text-slate-100 placeholder-slate-500 text-sm py-2.5 px-1 focus:outline-none resize-none leading-relaxed"
        />

        <button
          type="submit"
          disabled={!text.trim() || isThinking}
          title="Send message"
          className={`shrink-0 w-11 h-11 rounded-xl flex items-center justify-center transition-all ${
            text.trim() && !isThinking
              ? 'bg-violet-600 hover:bg-violet-500 text-white shadow-lg shadow-violet-600/25 active:scale-95'
              : 'text-slate-600 bg-slate-800/40 cursor-not-allowed'
          }`}
        >
          <Send className="w-4 h-4" />
        </button>
      </form>
    </div>
  );
};
