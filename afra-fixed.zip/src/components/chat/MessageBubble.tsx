import React, { useState } from 'react';
import { ChatMessage } from '../../types';
import { Volume2, VolumeX, Copy, Check, Sparkles } from 'lucide-react';

interface MessageBubbleProps {
  message: ChatMessage;
  onSpeak?: (text: string) => void;
  isSpeakingThis?: boolean;
  avatarThumbUrl?: string;
  avatarName?: string;
}

export const MessageBubble: React.FC<MessageBubbleProps> = ({
  message,
  onSpeak,
  isSpeakingThis = false,
  avatarThumbUrl,
  avatarName = 'AFRA',
}) => {
  const [copied, setCopied] = useState(false);
  const isUser = message.role === 'user';

  const copyToClipboard = () => {
    navigator.clipboard.writeText(message.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const formattedTime = new Date(message.timestamp).toLocaleTimeString([], {
    hour: '2-digit',
    minute: '2-digit',
  });

  return (
    <div
      className={`flex w-full gap-3 py-2 px-1 ${
        isUser ? 'justify-end' : 'justify-start'
      }`}
    >
      {!isUser && (
        <div className="shrink-0 w-8 h-8 rounded-full overflow-hidden border border-slate-700/80 bg-slate-900 mt-1 flex items-center justify-center">
          {avatarThumbUrl ? (
            <img
              src={avatarThumbUrl}
              alt={avatarName}
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover"
            />
          ) : (
            <Sparkles className="w-4 h-4 text-violet-400" />
          )}
        </div>
      )}

      <div
        className={`relative max-w-[85%] sm:max-w-[75%] rounded-2xl px-4 py-3 text-sm leading-relaxed transition-all duration-150 ${
          isUser
            ? 'bg-slate-800 text-white rounded-br-sm border border-slate-700/70 shadow-md'
            : 'bg-slate-900/90 text-slate-100 rounded-bl-sm border border-slate-800/90 shadow-lg'
        }`}
      >
        {/* Author & Actions Header for Assistant */}
        {!isUser && (
          <div className="flex items-center justify-between gap-4 pb-1.5 mb-1.5 border-b border-slate-800/70 text-xs text-slate-400">
            <div className="flex items-center gap-1.5 font-medium text-slate-200 font-display">
              <span>{avatarName}</span>
              <span className="text-[10px] text-violet-400 font-normal">Core</span>
            </div>

            <div className="flex items-center gap-1">
              {onSpeak && (
                <button
                  onClick={() => onSpeak(message.content)}
                  title={isSpeakingThis ? 'Speaking...' : 'Read aloud'}
                  className="p-1 rounded hover:bg-slate-800 text-slate-400 hover:text-slate-200 transition-colors"
                >
                  {isSpeakingThis ? (
                    <VolumeX className="w-3.5 h-3.5 text-violet-400 animate-pulse" />
                  ) : (
                    <Volume2 className="w-3.5 h-3.5" />
                  )}
                </button>
              )}
              <button
                onClick={copyToClipboard}
                title="Copy message"
                className="p-1 rounded hover:bg-slate-800 text-slate-400 hover:text-slate-200 transition-colors"
              >
                {copied ? (
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                ) : (
                  <Copy className="w-3.5 h-3.5" />
                )}
              </button>
            </div>
          </div>
        )}

        {/* Message Content with Streaming Cursor */}
        <div className="whitespace-pre-wrap break-words space-y-2">
          {message.content ? (
            message.content.includes('*AFRA Core Notice*') || message.content.includes('*AFRA System Error*') ? (
              <div className="p-2.5 rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-200 text-xs leading-relaxed">
                {formatTextWithCode(message.content)}
              </div>
            ) : (
              formatTextWithCode(message.content)
            )
          ) : message.isStreaming ? (
            <span className="inline-flex items-center gap-1.5 text-slate-400 italic text-xs">
              <span className="w-2 h-2 rounded-full bg-violet-400 animate-pulse" />
              AFRA is formulating response...
            </span>
          ) : (
            <span className="text-xs text-slate-500 italic">
              No response generated. Please retry.
            </span>
          )}

          {message.isStreaming && message.content && (
            <span className="inline-block w-1.5 h-3.5 ml-1 bg-violet-400 animate-pulse align-middle" />
          )}
        </div>

        {/* Footer Timestamp */}
        <div
          className={`flex items-center gap-1 mt-2 text-[10px] tabular-nums ${
            isUser ? 'text-slate-400 justify-end' : 'text-slate-500 justify-end'
          }`}
        >
          <span>{formattedTime}</span>
        </div>
      </div>
    </div>
  );
};

// Simple Markdown code block formatter
function formatTextWithCode(text: string) {
  const parts = text.split(/(```[\s\S]*?```)/g);

  return parts.map((part, index) => {
    if (part.startsWith('```') && part.endsWith('```')) {
      const codeLines = part.slice(3, -3).trim().split('\n');
      const firstLine = codeLines[0].trim();
      const isLang = /^[a-z0-9_-]+$/i.test(firstLine);
      const language = isLang ? firstLine : '';
      const code = isLang ? codeLines.slice(1).join('\n') : codeLines.join('\n');

      return (
        <div
          key={index}
          className="my-2 rounded-xl bg-slate-950 border border-slate-800/80 p-3 font-mono text-xs overflow-x-auto text-slate-200"
        >
          {language && (
            <div className="text-[10px] text-slate-500 uppercase tracking-wider mb-1.5 border-b border-slate-800/50 pb-1">
              {language}
            </div>
          )}
          <code>{code}</code>
        </div>
      );
    }

    return <span key={index}>{part}</span>;
  });
}
