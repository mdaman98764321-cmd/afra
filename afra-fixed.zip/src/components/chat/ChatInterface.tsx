import React, { useRef, useEffect } from 'react';
import { useConversation } from '../../context/ConversationContext';
import { useAvatarEngine } from '../../context/AvatarEngineContext';
import { useSettings } from '../../context/SettingsContext';
import { MessageBubble } from './MessageBubble';
import { ChatInput } from './ChatInput';
import { AvatarRenderer } from '../avatar/AvatarRenderer';
import { ApiKeyStorage } from '../../services/apiKeyStorage';
import { Mic, Trash2, Sliders, Sparkles, Key, ArrowRight } from 'lucide-react';

const SUGGESTIONS = [
  'Synthesize a cinematic dark UI architecture plan',
  'Design an interactive Canvas particle ring avatar in JavaScript',
  'Explain quantum entanglement in 3 clear bullet points',
  'Compose an executive strategy brief for autonomous AI agents',
];

interface ChatInterfaceProps {
  onNavigateToSettings?: () => void;
}

export const ChatInterface: React.FC<ChatInterfaceProps> = ({ onNavigateToSettings }) => {
  const {
    messages,
    isThinking,
    isListening,
    isSpeaking,
    sendMessage,
    clearConversation,
    startVoiceListening,
    stopVoiceListening,
    speakMessage,
    setVoiceOverlayOpen,
  } = useConversation();

  const { activeAvatar, avatarState, audioLevel, setAvatarState, setAudioLevel } = useAvatarEngine();
  const { settings, updateSettings } = useSettings();
  const [hasApiKey, setHasApiKey] = React.useState<boolean>(() => ApiKeyStorage.hasApiKey());

  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isThinking]);

  useEffect(() => {
    setHasApiKey(ApiKeyStorage.hasApiKey());
  }, [messages]);

  return (
    <div className="flex flex-col h-full bg-[#0b0d10] relative">
      {/* Missing Key Notification Banner */}
      {!hasApiKey && (
        <div className="shrink-0 bg-amber-950/40 border-b border-amber-900/50 px-4 py-2.5 flex items-center justify-between text-xs text-amber-200">
          <div className="flex items-center gap-2">
            <Key className="w-3.5 h-3.5 text-amber-400 shrink-0" />
            <span>
              <strong>Personal API Key Required:</strong> Add your Gemini key in Settings to activate AFRA AI.
            </span>
          </div>
          {onNavigateToSettings && (
            <button
              onClick={onNavigateToSettings}
              className="flex items-center gap-1 font-semibold text-amber-300 hover:text-white underline underline-offset-2 transition-colors ml-3 shrink-0"
            >
              <span>Configure Now</span>
              <ArrowRight className="w-3 h-3" />
            </button>
          )}
        </div>
      )}

      {/* Top Bar for Chat: Active Avatar Presence */}
      <div className="shrink-0 flex items-center justify-between px-4 py-3 border-b border-slate-800/80 bg-slate-950/60 backdrop-blur-md">
        <div className="flex items-center gap-3">
          <div className="relative">
            <AvatarRenderer
              avatar={activeAvatar}
              state={avatarState}
              audioLevel={audioLevel}
              size="sm"
              showHalo={false}
            />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-sm font-semibold text-white font-display">
                {activeAvatar.name}
              </span>
              <span className="text-[11px] text-slate-400">·</span>
              <span className="text-[11px] text-slate-400 capitalize">{avatarState}</span>
            </div>
            <p className="text-xs text-slate-400 line-clamp-1 max-w-[200px] sm:max-w-xs">
              {activeAvatar.tagline}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-1.5">
          <button
            onClick={() => setVoiceOverlayOpen(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium bg-slate-800/90 hover:bg-slate-700/90 text-slate-200 hover:text-white rounded-lg border border-slate-700/80 transition-colors"
            title="Open Voice Assistant Interface"
          >
            <Mic className="w-3.5 h-3.5 text-cyan-400" />
            <span className="hidden sm:inline">Voice Mode</span>
          </button>

          <button
            onClick={clearConversation}
            className="p-2 text-slate-500 hover:text-slate-300 hover:bg-slate-800/60 rounded-lg transition-colors"
            title="Clear Chat History"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Messages Scroll Area */}
      <div className="flex-1 overflow-y-auto p-4 space-y-3">
        {messages.map((msg) => (
          <MessageBubble
            key={msg.id}
            message={msg}
            onSpeak={speakMessage}
            isSpeakingThis={isSpeaking}
            avatarThumbUrl={activeAvatar.imageUrl}
            avatarName={activeAvatar.name}
          />
        ))}

        {/* Suggestion Prompts if conversation is short */}
        {messages.length <= 2 && (
          <div className="pt-4 max-w-2xl mx-auto">
            <div className="flex items-center gap-1.5 text-xs text-slate-500 mb-2 px-1">
              <Sparkles className="w-3.5 h-3.5 text-violet-400" />
              <span>Prompt Starters</span>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {SUGGESTIONS.map((suggestion, idx) => (
                <button
                  key={idx}
                  onClick={() => sendMessage(suggestion)}
                  className="text-left p-3 rounded-xl bg-slate-900/60 hover:bg-slate-800/80 border border-slate-800/80 text-xs text-slate-300 hover:text-white transition-all duration-150 line-clamp-2"
                >
                  {suggestion}
                </button>
              ))}
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Chat Input */}
      <ChatInput
        onSendMessage={sendMessage}
        onVoiceTrigger={() => {
          if (isListening) {
            stopVoiceListening();
          } else {
            startVoiceListening();
          }
        }}
        isListening={isListening}
        isThinking={isThinking}
        personaMode={settings.personaMode}
        onPersonaChange={(mode) => updateSettings({ personaMode: mode })}
      />
    </div>
  );
};
