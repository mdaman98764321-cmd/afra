import React, { useState, useEffect } from 'react';
import { useSettings } from '../../context/SettingsContext';
import { AppTheme, PersonaMode } from '../../types';
import { SpeechAudioService, SpeechVoiceOption } from '../../services/speech';
import { VOICE_PROFILES } from '../../services/voiceProfiles';
import {
  KOTLIN_OVERLAY_SERVICE_CODE,
  KOTLIN_QUICK_ACTION_MENU_CODE,
  KOTLIN_BRIDGE_CODE,
  JETPACK_COMPOSE_SPEC,
  ANDROID_MANIFEST_SNIPPET,
} from '../../services/androidBridgeSpec';
import { ApiConfigurationSection } from './ApiConfigurationSection';
import {
  Palette,
  Volume2,
  Sparkles,
  Smartphone,
  Copy,
  Check,
  RotateCcw,
  Sliders,
  ShieldCheck,
} from 'lucide-react';

const THEMES: { id: AppTheme; label: string; desc: string; preview: string }[] = [
  {
    id: 'obsidian',
    label: 'Obsidian Noir',
    desc: 'Matte obsidian canvas with glowing soft violet and titanium accents',
    preview: 'from-[#0b0d10] via-[#12161f] to-violet-950/40',
  },
  {
    id: 'charcoal',
    label: 'Matte Charcoal',
    desc: 'Industrial matte graphite with electric cyan illumination',
    preview: 'from-[#0e1117] via-[#161c24] to-cyan-950/40',
  },
  {
    id: 'violet-noir',
    label: 'Violet Aurora',
    desc: 'Deep midnight nebula with rich luminescent purple tones',
    preview: 'from-[#0d0914] via-[#1a1228] to-purple-900/40',
  },
  {
    id: 'silver-edge',
    label: 'Titanium Silver',
    desc: 'Clean brushed titanium geometry with high-contrast chrome trims',
    preview: 'from-[#0a0c10] via-[#1a202c] to-slate-800',
  },
];

const PERSONA_PRESETS = [
  {
    title: 'Executive Advisor',
    desc: 'Poised, strategic, concise, and focused on high-level decisions.',
    prompt: 'You are an elite executive strategy consultant. Provide high-density, actionable insights with supreme polish.',
  },
  {
    title: 'Scientific Futurist',
    desc: 'Deeply knowledgeable in quantum physics, synthetic biology, and aerospace.',
    prompt: 'You are a senior research scientist specializing in breakthrough computational frontiers and deep tech.',
  },
  {
    title: 'Lead Software Architect',
    desc: 'Clean code fanatic, systems thinker, pragmatic engineer.',
    prompt: 'You are a principal software architect with deep expertise in distributed systems, mobile native Kotlin, and full-stack engineering.',
  },
];

export const SettingsView: React.FC = () => {
  const { settings, updateSettings, resetSettings } = useSettings();
  const [voices, setVoices] = useState<SpeechVoiceOption[]>([]);
  const [activeAndroidTab, setActiveAndroidTab] = useState<'overlay' | 'menu' | 'bridge' | 'compose' | 'manifest'>('overlay');
  const [copiedKey, setCopiedKey] = useState<string | null>(null);
  const [testingVoiceKey, setTestingVoiceKey] = useState<string | null>(null);
  const [voiceTestError, setVoiceTestError] = useState<string | null>(null);

  useEffect(() => {
    const list = SpeechAudioService.getVoices();
    setVoices(list);
    // Listen for voiceschanged event if available
    if ('speechSynthesis' in window) {
      window.speechSynthesis.onvoiceschanged = () => {
        setVoices(SpeechAudioService.getVoices());
      };
    }
  }, []);

  const handleCopy = (key: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  return (
    <div className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8 space-y-8 max-w-5xl mx-auto w-full">
      {/* Settings Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl sm:text-2xl font-semibold text-white font-display tracking-tight">
            Settings & Customization
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Configure personal API credentials, UI themes, speech synthesis voice, AI persona directives, and inspect the Android Kotlin bridge.
          </p>
        </div>

        <button
          onClick={resetSettings}
          className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-400 hover:text-white bg-slate-900 hover:bg-slate-800 border border-slate-800 rounded-xl transition-colors w-fit"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span>Reset to Defaults</span>
        </button>
      </div>

      {/* Section 0: Personal API Key Management (BYOK) */}
      <ApiConfigurationSection />

      {/* Section 1: Themes */}
      <section className="space-y-4">
        <div className="flex items-center gap-2">
          <Palette className="w-4 h-4 text-violet-400" />
          <h3 className="text-sm font-semibold text-slate-200 font-display">Cinematic Dark Themes</h3>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {THEMES.map((theme) => {
            const isSelected = settings.theme === theme.id;
            return (
              <button
                key={theme.id}
                onClick={() => updateSettings({ theme: theme.id })}
                className={`flex flex-col text-left p-4 rounded-2xl border transition-all duration-150 ${
                  isSelected
                    ? 'border-violet-500 bg-slate-900/90 shadow-lg shadow-violet-500/10'
                    : 'border-slate-800/80 bg-slate-900/40 hover:border-slate-700/80 hover:bg-slate-900/60'
                }`}
              >
                <div className="flex items-center justify-between w-full mb-2">
                  <span className="text-sm font-medium text-white font-display">{theme.label}</span>
                  {isSelected && <Check className="w-4 h-4 text-violet-400" />}
                </div>
                <p className="text-xs text-slate-400 leading-relaxed mb-3">{theme.desc}</p>
                <div className={`w-full h-3 rounded-full bg-gradient-to-r ${theme.preview}`} />
              </button>
            );
          })}
        </div>
      </section>

      {/* Section 2: Female Voice Profiles & Synthesis Engine */}
      <section className="space-y-6 p-6 rounded-3xl bg-slate-900/60 border border-slate-800/80">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-2 border-b border-slate-800/80">
          <div className="flex items-center gap-2">
            <Volume2 className="w-4 h-4 text-cyan-400" />
            <div>
              <h3 className="text-sm font-semibold text-slate-200 font-display">
                Selectable Female Voice Profiles
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                High-fidelity feminine neural audio powered by Gemini TTS with natural Bangla, Banglish & English articulation.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1.5 text-[11px] text-emerald-400 font-mono bg-emerald-950/40 border border-emerald-800/40 px-2.5 py-1 rounded-full w-fit">
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>Strict Female Voice Guarantee</span>
          </div>
        </div>

        {/* The Two Dedicated Female Voice Profiles */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {(['afra-soft', 'afra-elegant'] as const).map((profileId) => {
            const profile = VOICE_PROFILES[profileId];
            const isSelected = settings.voiceProfile === profileId;
            const isTestingThisEn = testingVoiceKey === `${profileId}-en`;
            const isTestingThisBn = testingVoiceKey === `${profileId}-bn`;

            return (
              <div
                key={profile.id}
                className={`relative flex flex-col justify-between p-5 rounded-2xl border transition-all duration-200 ${
                  isSelected
                    ? 'border-violet-500 bg-slate-900/90 shadow-xl shadow-violet-500/10'
                    : 'border-slate-800/80 bg-slate-950/40 hover:border-slate-700/80 hover:bg-slate-900/50'
                }`}
              >
                <div>
                  {/* Top Bar with Name & Active Tag */}
                  <div className="flex items-start justify-between gap-3 mb-2">
                    <div>
                      <div className="flex items-center gap-2">
                        <h4 className="text-base font-semibold text-white font-display">
                          {profile.name}
                        </h4>
                        <span className="text-[10px] text-cyan-400 font-mono bg-cyan-950/50 border border-cyan-800/40 px-2 py-0.5 rounded-full">
                          {profile.geminiVoice}
                        </span>
                      </div>
                      <p className="text-xs text-slate-300 mt-1 leading-relaxed">
                        {profile.tagline}
                      </p>
                    </div>

                    <button
                      onClick={() => updateSettings({ voiceProfile: profile.id })}
                      className={`shrink-0 flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                        isSelected
                          ? 'bg-violet-600 text-white shadow-sm shadow-violet-600/30'
                          : 'bg-slate-800 text-slate-300 hover:text-white hover:bg-slate-700'
                      }`}
                    >
                      {isSelected ? (
                        <>
                          <Check className="w-3.5 h-3.5" />
                          <span>Active</span>
                        </>
                      ) : (
                        <span>Select</span>
                      )}
                    </button>
                  </div>

                  {/* Characteristics tags with clean unboxed styling (Constitution §1.A) */}
                  <div className="flex flex-wrap items-center gap-1.5 text-[11px] text-slate-400 my-3">
                    {profile.characteristics.map((c, i) => (
                      <React.Fragment key={i}>
                        {i > 0 && <span aria-hidden="true" className="text-slate-600">·</span>}
                        <span>{c}</span>
                      </React.Fragment>
                    ))}
                  </div>
                </div>

                {/* Test Voice Buttons (English & Bangla) */}
                <div className="pt-3 border-t border-slate-800/80 flex items-center gap-2 mt-2">
                  <button
                    onClick={async () => {
                      setVoiceTestError(null);
                      setTestingVoiceKey(`${profileId}-en`);
                      try {
                        await SpeechAudioService.testVoiceProfile(profile.id, false);
                      } catch (err: any) {
                        setVoiceTestError(err?.message || 'Voice playback error');
                      } finally {
                        setTestingVoiceKey(null);
                      }
                    }}
                    className={`flex-1 flex items-center justify-center gap-1.5 py-2 px-2.5 rounded-xl text-xs font-medium border transition-colors ${
                      isTestingThisEn
                        ? 'bg-violet-600 text-white border-violet-500 animate-pulse'
                        : 'bg-slate-900 hover:bg-slate-800 text-slate-200 border-slate-800'
                    }`}
                  >
                    <Volume2 className="w-3.5 h-3.5 text-violet-400" />
                    <span>{isTestingThisEn ? 'Playing...' : 'Test English'}</span>
                  </button>

                  <button
                    onClick={async () => {
                      setVoiceTestError(null);
                      setTestingVoiceKey(`${profileId}-bn`);
                      try {
                        await SpeechAudioService.testVoiceProfile(profile.id, true);
                      } catch (err: any) {
                        setVoiceTestError(err?.message || 'Voice playback error');
                      } finally {
                        setTestingVoiceKey(null);
                      }
                    }}
                    className={`flex-1 flex items-center justify-center gap-1.5 py-2 px-2.5 rounded-xl text-xs font-medium border transition-colors ${
                      isTestingThisBn
                        ? 'bg-cyan-600 text-white border-cyan-500 animate-pulse'
                        : 'bg-slate-900 hover:bg-slate-800 text-slate-200 border-slate-800'
                    }`}
                  >
                    <Volume2 className="w-3.5 h-3.5 text-cyan-400" />
                    <span>{isTestingThisBn ? 'Playing...' : 'Test বাংলা (Bangla)'}</span>
                  </button>
                </div>
              </div>
            );
          })}
        </div>

        {voiceTestError && (
          <div className="p-3 rounded-xl bg-rose-950/40 border border-rose-900/50 text-xs text-rose-300">
            {voiceTestError}
          </div>
        )}

        {/* Sliders: Rate & Pitch */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 pt-3 border-t border-slate-800/70">
          <div className="space-y-1.5">
            <div className="flex justify-between text-xs text-slate-400">
              <span>Voice Speed (Pacing)</span>
              <span className="font-mono tabular-nums text-slate-200">
                {settings.speechRate.toFixed(2)}x
              </span>
            </div>
            <input
              type="range"
              min="0.8"
              max="1.3"
              step="0.05"
              value={settings.speechRate}
              onChange={(e) => updateSettings({ speechRate: parseFloat(e.target.value) })}
              className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-cyan-400"
            />
          </div>

          <div className="space-y-1.5">
            <div className="flex justify-between text-xs text-slate-400">
              <span>Voice Pitch (Timbre)</span>
              <span className="font-mono tabular-nums text-slate-200">
                {settings.speechPitch.toFixed(2)}x
              </span>
            </div>
            <input
              type="range"
              min="0.85"
              max="1.25"
              step="0.05"
              value={settings.speechPitch}
              onChange={(e) => updateSettings({ speechPitch: parseFloat(e.target.value) })}
              className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-cyan-400"
            />
          </div>
        </div>

        {/* Toggles */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-3 border-t border-slate-800/60">
          <label className="flex items-center gap-2 cursor-pointer text-xs text-slate-300">
            <input
              type="checkbox"
              checked={settings.autoSpeakResponse}
              onChange={(e) => updateSettings({ autoSpeakResponse: e.target.checked })}
              className="rounded bg-slate-950 border-slate-700 text-violet-500 focus:ring-0"
            />
            <span>Auto-read Chat Responses</span>
          </label>

          <label className="flex items-center gap-2 cursor-pointer text-xs text-slate-300">
            <input
              type="checkbox"
              checked={settings.soundEffects}
              onChange={(e) => updateSettings({ soundEffects: e.target.checked })}
              className="rounded bg-slate-950 border-slate-700 text-violet-500 focus:ring-0"
            />
            <span>Procedural Sound FX</span>
          </label>

          <label className="flex items-center gap-2 cursor-pointer text-xs text-slate-300">
            <input
              type="checkbox"
              checked={settings.showStateControls}
              onChange={(e) => updateSettings({ showStateControls: e.target.checked })}
              className="rounded bg-slate-950 border-slate-700 text-violet-500 focus:ring-0"
            />
            <span>Show State Simulation Dock</span>
          </label>
        </div>
      </section>

      {/* Section 3: AI Persona Tuning */}
      <section className="space-y-4 p-6 rounded-3xl bg-slate-900/60 border border-slate-800/80">
        <div className="flex items-center gap-2">
          <Sparkles className="w-4 h-4 text-violet-400" />
          <h3 className="text-sm font-semibold text-slate-200 font-display">
            AFRA Persona Directives
          </h3>
        </div>

        {/* Persona Presets */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          {PERSONA_PRESETS.map((preset) => (
            <button
              key={preset.title}
              type="button"
              onClick={() => updateSettings({ customPersona: preset.prompt })}
              className="p-3 text-left rounded-xl bg-slate-950/60 hover:bg-slate-900 border border-slate-800 hover:border-slate-700 transition-colors"
            >
              <div className="text-xs font-semibold text-white font-display mb-1">{preset.title}</div>
              <p className="text-[11px] text-slate-400 line-clamp-2">{preset.desc}</p>
            </button>
          ))}
        </div>

        <div>
          <label className="block text-xs font-medium text-slate-300 mb-1">
            Custom Persona Instruction
          </label>
          <textarea
            rows={3}
            value={settings.customPersona}
            onChange={(e) => updateSettings({ customPersona: e.target.value })}
            placeholder="Add custom behavioral instructions to modify how AFRA interacts..."
            className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-200 placeholder-slate-600 focus:outline-none focus:border-violet-500 resize-none leading-relaxed"
          />
        </div>
      </section>

      {/* Section 4: Android Kotlin Bridge Architecture Spec */}
      <section className="space-y-4 p-6 rounded-3xl bg-slate-900/60 border border-slate-800/80">
        <div className="flex items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <Smartphone className="w-4 h-4 text-cyan-400" />
            <div>
              <h3 className="text-sm font-semibold text-slate-200 font-display">
                Native Android Kotlin Integration Architecture
              </h3>
              <p className="text-xs text-slate-400">
                Architectural contracts for wrapping this engine into native Android via WebView & Jetpack Compose.
              </p>
            </div>
          </div>
        </div>

        {/* Tab switcher for Kotlin files */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-2">
          <div className="flex flex-wrap items-center gap-1.5">
            {(
              [
                { id: 'overlay', label: 'AfraOverlayService.kt' },
                { id: 'menu', label: 'QuickActionMenu.kt' },
                { id: 'bridge', label: 'AfraNativeBridge.kt' },
                { id: 'compose', label: 'AfraScreen.kt' },
                { id: 'manifest', label: 'AndroidManifest.xml' },
              ] as const
            ).map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveAndroidTab(tab.id)}
                className={`px-2.5 py-1 text-xs font-medium rounded-lg transition-colors font-mono ${
                  activeAndroidTab === tab.id
                    ? 'bg-slate-800 text-white border border-slate-700'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          <button
            onClick={() => {
              const code =
                activeAndroidTab === 'overlay'
                  ? KOTLIN_OVERLAY_SERVICE_CODE
                  : activeAndroidTab === 'menu'
                  ? KOTLIN_QUICK_ACTION_MENU_CODE
                  : activeAndroidTab === 'bridge'
                  ? KOTLIN_BRIDGE_CODE
                  : activeAndroidTab === 'compose'
                  ? JETPACK_COMPOSE_SPEC
                  : ANDROID_MANIFEST_SNIPPET;
              handleCopy(activeAndroidTab, code);
            }}
            className="flex items-center gap-1.5 px-2.5 py-1 text-xs font-medium text-slate-300 hover:text-white bg-slate-800 rounded-lg transition-colors self-start sm:self-auto"
          >
            {copiedKey === activeAndroidTab ? (
              <>
                <Check className="w-3.5 h-3.5 text-emerald-400" />
                <span>Copied</span>
              </>
            ) : (
              <>
                <Copy className="w-3.5 h-3.5" />
                <span>Copy Code</span>
              </>
            )}
          </button>
        </div>

        {/* Code View */}
        <pre className="p-4 rounded-2xl bg-slate-950 border border-slate-800/80 font-mono text-xs text-slate-300 overflow-x-auto leading-relaxed max-h-72">
          {activeAndroidTab === 'overlay'
            ? KOTLIN_OVERLAY_SERVICE_CODE
            : activeAndroidTab === 'menu'
            ? KOTLIN_QUICK_ACTION_MENU_CODE
            : activeAndroidTab === 'bridge'
            ? KOTLIN_BRIDGE_CODE
            : activeAndroidTab === 'compose'
            ? JETPACK_COMPOSE_SPEC
            : ANDROID_MANIFEST_SNIPPET}
        </pre>
      </section>
    </div>
  );
};
