import React, { useEffect } from 'react';
import { useConversation } from '../../context/ConversationContext';
import { useAvatarEngine } from '../../context/AvatarEngineContext';
import { useSettings } from '../../context/SettingsContext';
import { AvatarRenderer } from '../avatar/AvatarRenderer';
import { StateSimulationController } from '../avatar/StateSimulationController';
import { X, Mic, MicOff, Volume2, Sparkles, Radio } from 'lucide-react';

export const VoiceAssistantOverlay: React.FC = () => {
  const {
    isVoiceOverlayOpen,
    setVoiceOverlayOpen,
    isListening,
    isThinking,
    isSpeaking,
    transcript,
    startVoiceListening,
    stopVoiceListening,
    stopSpeaking,
  } = useConversation();

  const { activeAvatar, avatarState, audioLevel, setAvatarState, setAudioLevel } = useAvatarEngine();
  const { settings, updateSettings } = useSettings();

  // Start listening automatically when overlay opens if idle
  useEffect(() => {
    if (isVoiceOverlayOpen && !isListening && !isThinking && !isSpeaking) {
      startVoiceListening();
    }
  }, [isVoiceOverlayOpen]);

  if (!isVoiceOverlayOpen) return null;

  const handleOrbClick = () => {
    if (isSpeaking) {
      stopSpeaking();
    } else if (isListening) {
      stopVoiceListening();
    } else {
      startVoiceListening();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex flex-col items-center justify-between bg-[#07090c]/95 backdrop-blur-2xl p-4 sm:p-6 text-white overflow-hidden animate-fade-in">
      {/* Background ambient radial glow */}
      <div
        className="absolute inset-0 pointer-events-none opacity-40 transition-colors duration-700"
        style={{
          background: `radial-gradient(circle at 50% 45%, ${
            avatarState === 'listening'
              ? 'rgba(6, 182, 212, 0.15)'
              : avatarState === 'thinking'
              ? 'rgba(168, 85, 247, 0.18)'
              : avatarState === 'speaking'
              ? 'rgba(139, 92, 246, 0.22)'
              : 'rgba(51, 65, 85, 0.1)'
          } 0%, transparent 65%)`,
        }}
      />

      {/* Top Header: AFRA Brand + Voice Profile Quick Switcher + Close Button */}
      <div className="w-full max-w-2xl flex items-center justify-between z-10 pt-2 gap-2 flex-wrap">
        <div className="flex items-center gap-2">
          <Radio className="w-4 h-4 text-violet-400 animate-pulse" />
          <span className="text-sm font-semibold tracking-wider font-display uppercase text-slate-200">
            AFRA Voice
          </span>
          <span className="text-xs text-slate-500">·</span>
          <span className="text-xs text-slate-400 capitalize">{avatarState}</span>
        </div>

        {/* Live Profile Switcher */}
        <div className="flex items-center gap-1 p-0.5 bg-slate-900/90 rounded-xl border border-slate-800">
          <button
            onClick={() => updateSettings({ voiceProfile: 'afra-soft' })}
            className={`px-2.5 py-1 text-xs font-medium rounded-lg transition-colors whitespace-nowrap ${
              settings.voiceProfile === 'afra-soft'
                ? 'bg-violet-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            AFRA Soft
          </button>
          <button
            onClick={() => updateSettings({ voiceProfile: 'afra-elegant' })}
            className={`px-2.5 py-1 text-xs font-medium rounded-lg transition-colors whitespace-nowrap ${
              settings.voiceProfile === 'afra-elegant'
                ? 'bg-violet-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            AFRA Elegant
          </button>
        </div>

        <button
          onClick={() => {
            stopVoiceListening();
            stopSpeaking();
            setVoiceOverlayOpen(false);
          }}
          className="p-2 rounded-full bg-slate-800/80 hover:bg-slate-700/80 text-slate-300 hover:text-white transition-colors"
          title="Exit voice mode"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      {/* Center Hero Avatar & Soundwave Orb */}
      <div className="relative flex flex-col items-center justify-center my-auto z-10">
        <button
          onClick={handleOrbClick}
          className="relative group cursor-pointer focus:outline-none"
          title="Tap to interact"
        >
          <AvatarRenderer
            avatar={activeAvatar}
            state={avatarState}
            audioLevel={audioLevel}
            size="hero"
            showHalo={true}
          />
        </button>

        {/* Dynamic State Status Label */}
        <div className="mt-8 text-center max-w-md px-4">
          <div className="text-lg sm:text-xl font-medium tracking-tight font-display mb-1 text-slate-100">
            {avatarState === 'listening'
              ? 'Listening to you...'
              : avatarState === 'thinking'
              ? 'Synthesizing response...'
              : avatarState === 'speaking'
              ? 'AFRA is speaking'
              : 'Tap to speak'}
          </div>

          {/* Real-time Transcription or Guidance */}
          <div className="min-h-[44px] flex items-center justify-center">
            {transcript ? (
              <p className="text-sm text-cyan-300/90 italic line-clamp-2 px-3 py-1.5 bg-slate-900/60 rounded-xl border border-cyan-500/30">
                "{transcript}"
              </p>
            ) : (
              <p className="text-xs text-slate-400">
                {avatarState === 'listening'
                  ? 'Speak naturally — voice recognition is active'
                  : avatarState === 'speaking'
                  ? 'Tap the avatar or microphone below to interrupt'
                  : 'Say anything to AFRA or tap the microphone to begin'}
              </p>
            )}
          </div>
        </div>

        {/* Audio Waveform Equalizer Bars */}
        <div className="flex items-center gap-1.5 mt-4 h-8">
          {[...Array(9)].map((_, i) => {
            const height =
              avatarState === 'speaking' || avatarState === 'listening'
                ? Math.max(4, Math.sin(i * 0.8 + audioLevel * 10) * 24 * audioLevel + 12)
                : 4;
            return (
              <div
                key={i}
                className="w-1 rounded-full transition-all duration-75"
                style={{
                  height: `${height}px`,
                  backgroundColor:
                    avatarState === 'listening'
                      ? '#06b6d4'
                      : avatarState === 'speaking'
                      ? '#8b5cf6'
                      : '#475569',
                }}
              />
            );
          })}
        </div>
      </div>

      {/* Bottom Controls */}
      <div className="w-full max-w-md flex flex-col items-center gap-4 z-10 pb-6">
        <div className="flex items-center gap-4">
          <button
            onClick={handleOrbClick}
            className={`w-16 h-16 rounded-full flex items-center justify-center text-white transition-all shadow-xl active:scale-95 ${
              avatarState === 'listening'
                ? 'bg-cyan-500 shadow-cyan-500/30 animate-pulse'
                : avatarState === 'speaking'
                ? 'bg-violet-600 shadow-violet-600/30'
                : 'bg-slate-800 hover:bg-slate-700 shadow-slate-900/40 border border-slate-700'
            }`}
          >
            {avatarState === 'listening' ? (
              <MicOff className="w-7 h-7" />
            ) : avatarState === 'speaking' ? (
              <Volume2 className="w-7 h-7" />
            ) : (
              <Mic className="w-7 h-7" />
            )}
          </button>
        </div>

        {/* State simulator collapsible option */}
        {settings.showStateControls && (
          <div className="w-full">
            <StateSimulationController
              currentState={avatarState}
              audioLevel={audioLevel}
              onStateChange={setAvatarState}
              onAudioLevelChange={setAudioLevel}
            />
          </div>
        )}
      </div>
    </div>
  );
};
