import React from 'react';
import { AvatarState } from '../../types';
import { Play, Mic, Brain, Volume2, Sliders, Smile, AlertCircle } from 'lucide-react';

interface StateSimulationControllerProps {
  currentState: AvatarState;
  audioLevel: number;
  onStateChange: (state: AvatarState) => void;
  onAudioLevelChange: (level: number) => void;
  className?: string;
}

export const StateSimulationController: React.FC<StateSimulationControllerProps> = ({
  currentState,
  audioLevel,
  onStateChange,
  onAudioLevelChange,
  className = '',
}) => {
  const states: { id: AvatarState; label: string; icon: React.ReactNode; color: string }[] = [
    { id: 'idle', label: 'Idle', icon: <Play className="w-3.5 h-3.5" />, color: 'text-slate-300' },
    { id: 'listening', label: 'Listening', icon: <Mic className="w-3.5 h-3.5" />, color: 'text-cyan-400' },
    { id: 'thinking', label: 'Thinking', icon: <Brain className="w-3.5 h-3.5" />, color: 'text-violet-400' },
    { id: 'speaking', label: 'Speaking', icon: <Volume2 className="w-3.5 h-3.5" />, color: 'text-emerald-400' },
    { id: 'happy', label: 'Happy', icon: <Smile className="w-3.5 h-3.5" />, color: 'text-amber-400' },
    { id: 'error', label: 'Error', icon: <AlertCircle className="w-3.5 h-3.5" />, color: 'text-rose-400' },
  ];

  return (
    <div className={`p-3.5 rounded-2xl bg-slate-900/80 backdrop-blur-md border border-slate-800/80 ${className}`}>
      <div className="flex items-center justify-between gap-3 mb-2.5">
        <div className="flex items-center gap-2">
          <Sliders className="w-3.5 h-3.5 text-slate-400" />
          <span className="text-xs font-medium text-slate-300">Avatar State Simulator</span>
        </div>
        <div className="flex items-center gap-1.5 text-[11px] text-slate-400">
          <span>Active</span>
          <span aria-hidden="true">·</span>
          <span className="font-semibold text-white capitalize">{currentState}</span>
        </div>
      </div>

      {/* Segmented Button Controls */}
      <div className="grid grid-cols-3 sm:grid-cols-6 gap-1 p-1 bg-slate-950/70 rounded-xl border border-slate-800/60 mb-3">
        {states.map((s) => {
          const isActive = currentState === s.id;
          return (
            <button
              key={s.id}
              onClick={() => {
                onStateChange(s.id);
                if (s.id === 'speaking' && audioLevel === 0) {
                  onAudioLevelChange(0.65);
                } else if (s.id === 'idle') {
                  onAudioLevelChange(0);
                }
              }}
              className={`flex items-center justify-center gap-1.5 py-2 px-2 rounded-lg text-xs font-medium transition-all duration-150 whitespace-nowrap ${
                isActive
                  ? 'bg-slate-800 text-white shadow-sm border border-slate-700/80'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
              }`}
            >
              <span className={isActive ? s.color : 'text-slate-400'}>{s.icon}</span>
              <span className="hidden sm:inline">{s.label}</span>
            </button>
          );
        })}
      </div>

      {/* Audio Reactive Frequency Slider */}
      <div className="space-y-1.5">
        <div className="flex items-center justify-between text-[11px] text-slate-400">
          <span>Voice Amplitude / Frequency Pulse</span>
          <span className="font-mono tabular-nums text-slate-200">
            {Math.round(audioLevel * 100)}%
          </span>
        </div>
        <input
          type="range"
          min="0"
          max="1"
          step="0.02"
          value={audioLevel}
          onChange={(e) => onAudioLevelChange(parseFloat(e.target.value))}
          className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-violet-400 focus:outline-none"
        />
      </div>
    </div>
  );
};
