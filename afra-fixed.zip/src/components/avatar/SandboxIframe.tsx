import React, { useEffect, useRef } from 'react';
import { AvatarState } from '../../types';

interface SandboxIframeProps {
  codeHtml?: string;
  codeCss?: string;
  codeJs?: string;
  bundledCode?: string;
  state: AvatarState;
  audioLevel: number;
  tintColor: string;
  className?: string;
}

export const SandboxIframe: React.FC<SandboxIframeProps> = ({
  codeHtml = '',
  codeCss = '',
  codeJs = '',
  bundledCode,
  state,
  audioLevel,
  tintColor,
  className = '',
}) => {
  const iframeRef = useRef<HTMLIFrameElement>(null);

  // Build isolated document content
  const srcDoc = bundledCode || `<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
    :root {
      --tint: ${tintColor};
    }
    body {
      margin: 0;
      padding: 0;
      background: #0b0d10;
      overflow: hidden;
      display: flex;
      align-items: center;
      justify-content: center;
      width: 100vw;
      height: 100vh;
      user-select: none;
    }
    ${codeCss}
  </style>
</head>
<body>
  ${codeHtml}
  <script>
    try {
      ${codeJs}
    } catch (err) {
      console.warn("Avatar sandbox script error:", err);
    }
  </script>
</body>
</html>`;

  // Send state messages into the sandbox
  useEffect(() => {
    const iframe = iframeRef.current;
    if (!iframe || !iframe.contentWindow) return;

    try {
      iframe.contentWindow.postMessage(
        {
          type: 'AFRA_STATE_UPDATE',
          state,
          audioLevel,
          tint: tintColor,
        },
        '*'
      );
    } catch (e) {
      // Cross-origin safe
    }
  }, [state, audioLevel, tintColor]);

  return (
    <iframe
      ref={iframeRef}
      title="AFRA Avatar Sandbox"
      srcDoc={srcDoc}
      sandbox="allow-scripts"
      className={`border-none pointer-events-none select-none ${className}`}
      style={{ background: 'transparent' }}
    />
  );
};
